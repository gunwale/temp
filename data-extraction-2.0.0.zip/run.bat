@echo off
setlocal enabledelayedexpansion

:: ── Detect local portable Node.js ──────────────────────────

set NODE_VER=20.12.2
set NODE_DIR=node-v%NODE_VER%-win-x64

if exist "%~dp0%NODE_DIR%\node.exe" (
    set "PATH=%~dp0%NODE_DIR%;%PATH%"
)

where node >nul 2>nul
if not %errorlevel%==0 (
    echo.
    echo   [ERROR] Node.js not found.
    echo           Run install.bat first.
    echo.
    pause
    exit /b 1
)

:: ── If arguments passed, run directly ──────────────────────

cd /d "%~dp0"

if not "%~1"=="" (
    node cli.mjs %*
    goto :end
)

:: ── Interactive menu ───────────────────────────────────────

echo.
echo   ============================================
echo   Data Extraction CLI
echo   ============================================
echo.
echo   What would you like to do?
echo.
echo     1. Export to Excel
echo     2. Export to PDF (artwork catalog)
echo     3. Show help
echo     0. Exit
echo.
set /p choice="  Enter choice (0-3): "

if "%choice%"=="0" goto :end
if "%choice%"=="3" (
    node cli.mjs help
    pause
    goto :end
)

if "%choice%"=="1" (
    set /p inputfile="  Path to couchdb.json: "
    set /p prefix="  Output prefix [export]: "
    if "!prefix!"=="" set prefix=export
    echo.
    node cli.mjs excel "!inputfile!" -o "!prefix!"
    pause
    goto :end
)

if "%choice%"=="2" (
    set /p inputfile="  Path to couchdb.json: "
    set /p outfile="  Output PDF name [artwork_catalog.pdf]: "
    if "!outfile!"=="" set outfile=artwork_catalog.pdf
    set /p imgdir="  Image directory (Enter to skip): "
    echo.
    if "!imgdir!"=="" (
        node cli.mjs pdf "!inputfile!" -o "!outfile!"
    ) else (
        node cli.mjs pdf "!inputfile!" -o "!outfile!" --images "!imgdir!"
    )
    pause
    goto :end
)

echo   Invalid choice.
pause

:end
endlocal
