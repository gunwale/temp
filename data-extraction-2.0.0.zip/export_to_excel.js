const fs = require('fs');
const xlsx = require('xlsx');

// Data loaded inside generateExcel

function camelToTitle(str) {
    if (!str) return '';
    let res = str.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
    // Special acronym cases
    res = res.replace(/Id$/i, 'ID');
    res = res.replace(/^Arn$/i, 'ARN');
    return res;
}

function getColumnName(parentPath, key) {
    let cleanKey = camelToTitle(key);
    
    if (!parentPath) return cleanKey;
    
    if (parentPath === 'data') return cleanKey;
    
    if (parentPath.startsWith('data_')) {
        let pathWithoutData = parentPath.substring(5); // remove 'data_'
        let cleanPath = pathWithoutData.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    
    if (parentPath.startsWith('metadata')) {
        let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    
    let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
    return `${cleanPath} ${cleanKey}`;
}

// Helper to flatten nested objects
function flattenObject(ob, parentPath = '') {
    const toReturn = {};

    for (const i in ob) {
        if (!ob.hasOwnProperty(i)) continue;
        
        let newPath = parentPath ? parentPath + '_' + i : i;

        if ((typeof ob[i]) === 'object' && ob[i] !== null) {
            if (Array.isArray(ob[i])) {
                // Serialize arrays and truncate if too long
                let str = JSON.stringify(ob[i]);
                if (str.length > 32000) str = str.substring(0, 32000) + '... [TRUNCATED]';
                toReturn[getColumnName(parentPath, i)] = str;
            } else {
                const flatObject = flattenObject(ob[i], newPath);
                for (const x in flatObject) {
                    if (!flatObject.hasOwnProperty(x)) continue;
                    toReturn[x] = flatObject[x];
                }
            }
        } else {
            let val = ob[i];
            if (typeof val === 'string' && val.length > 32000) {
                val = val.substring(0, 32000) + '... [TRUNCATED]';
            }
            toReturn[getColumnName(parentPath, i)] = val;
        }
    }
    return toReturn;
}

function generateExcel(inputFilePath, outputPrefix = 'couchdb_export') {
    console.log(`Loading ${inputFilePath}...`);
    const rawData = fs.readFileSync(inputFilePath, 'utf8');
    const data = JSON.parse(rawData);

    const collections = {};

    console.log('Processing documents...');
    for (const row of data.rows) {
        if (!row.doc) continue;
        const doc = row.doc;
        
        let docType = null;
        if (doc.metadata && doc.metadata.docType) docType = doc.metadata.docType;
        else if (doc.docType) docType = doc.docType;
        else if (doc.type) docType = doc.type;

        if (!docType || docType.startsWith('_design/')) continue;

        let isGift = false;
        if (doc.data && doc.data.isGift === true) {
            isGift = true;
        }

        // Strip CouchDB internal fields
        delete doc._id;
        delete doc._rev;
        delete doc['~version'];
        delete doc._attachments;
        delete doc._conflicts;

        const flattenedDoc = flattenObject(doc);

        let sheetName = docType.replace('io.uob.resources.', '');
        if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

        let collectionName = sheetName;
        if (sheetName === 'artifact') {
            collectionName = isGift ? 'gift' : 'artwork';
        }

        if (!collections[collectionName]) collections[collectionName] = [];
        collections[collectionName].push(flattenedDoc);
    }

    // Function to write a workbook
    function writeWorkbook(records, fileName, sheetName) {
        console.log(`Creating workbook ${fileName}...`);
        console.log(`  Adding sheet ${sheetName} with ${records.length} records...`);
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(records);
        let safeSheetName = sheetName;
        if (safeSheetName.length > 31) safeSheetName = safeSheetName.substring(0, 31);
        xlsx.utils.book_append_sheet(wb, ws, safeSheetName);
        console.log(`  Writing to ${fileName}...`);
        xlsx.writeFile(wb, fileName);
    }

    for (const [collectionName, records] of Object.entries(collections)) {
        const fileName = outputPrefix.includes('.') 
            ? outputPrefix.replace('.xlsx', `_${collectionName}.xlsx`) 
            : `${outputPrefix}_${collectionName}.xlsx`;
        writeWorkbook(records, fileName, collectionName);
    }

    console.log('Export completed successfully!');
}

if (require.main === module) {
    // Generate both files based on prefix
    generateExcel('couchdb.json', 'couchdb');
}

module.exports = {
    generateExcel,
    flattenObject
};
