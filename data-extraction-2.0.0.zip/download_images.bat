@echo off
setlocal enabledelayedexpansion

echo.
echo   ============================================
echo   Download S3 Artifact Images
echo   ============================================
echo.

:: ── Check AWS CLI ──────────────────────────────────────────

where aws >nul 2>nul
if %errorlevel% neq 0 (
    echo   [ERROR] AWS CLI not found. Install it from:
    echo   https://aws.amazon.com/cli/
    echo.
    pause
    exit /b 1
)

:: ── Bucket name ────────────────────────────────────────────

set BUCKET_NAME=%1
if "%BUCKET_NAME%"=="" (
    echo   Enter your S3 bucket name:
    echo   (e.g. my-app-storage-bucket-12345)
    echo.
    set /p BUCKET_NAME="   Bucket: "
)

if "%BUCKET_NAME%"=="" (
    echo   [ERROR] No bucket name provided.
    pause
    exit /b 1
)

:: ── AWS Profile (optional) ─────────────────────────────────

set AWS_PROFILE_ARG=
set PROFILE=%2
if "%PROFILE%"=="" (
    echo.
    echo   Enter AWS profile name (leave blank for default):
    set /p PROFILE="   Profile: "
)
if not "%PROFILE%"=="" (
    set AWS_PROFILE_ARG=--profile %PROFILE%
)

:: ── Target directory ───────────────────────────────────────

set TARGET_DIR=%~dp0s3\protected\common\artifact
set S3_PATH=s3://%BUCKET_NAME%/protected/common/artifact/

echo.
echo   ────────────────────────────────────────────
echo   Bucket:  %BUCKET_NAME%
echo   S3 path: %S3_PATH%
echo   Local:   %TARGET_DIR%
if not "%PROFILE%"=="" echo   Profile: %PROFILE%
echo   ────────────────────────────────────────────
echo.

:: ── Dry run first ──────────────────────────────────────────

echo   [1/2] Previewing files to download (dry run)...
echo.

aws s3 sync "%S3_PATH%" "%TARGET_DIR%" --exclude "*" --include "*.jpg" --include "*.jpeg" --include "*.png" --dryrun %AWS_PROFILE_ARG%

echo.
echo   ────────────────────────────────────────────
set /p CONFIRM="   Proceed with download? (Y/N): "
if /i not "%CONFIRM%"=="Y" (
    echo   Download cancelled.
    pause
    exit /b 0
)

:: ── Actual download ────────────────────────────────────────

echo.
echo   [2/2] Downloading images...
echo.

aws s3 sync "%S3_PATH%" "%TARGET_DIR%" --exclude "*" --include "*.jpg" --include "*.jpeg" --include "*.png" %AWS_PROFILE_ARG%

if %errorlevel%==0 (
    echo.
    echo   ============================================
    echo   [OK] Images downloaded successfully!
    echo   Location: %TARGET_DIR%
    echo   ============================================
    echo.
    echo   You can now generate PDFs with images:
    echo   node cli.mjs pdf couchdb.json --images ./s3
    echo.
) else (
    echo.
    echo   [ERROR] Download failed. Check your AWS credentials
    echo   and bucket name.
    echo.
)

pause
