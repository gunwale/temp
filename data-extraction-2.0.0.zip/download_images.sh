#!/bin/bash
echo ""
echo "  ============================================"
echo "  Download S3 Artifact Images"
echo "  ============================================"
echo ""

# ── Check AWS CLI ──
if ! command -v aws &> /dev/null; then
    echo "  [ERROR] AWS CLI not found. Install it from:"
    echo "  https://aws.amazon.com/cli/"
    exit 1
fi

# ── Bucket name ──
BUCKET_NAME="${1}"
if [ -z "$BUCKET_NAME" ]; then
    echo "  Enter your S3 bucket name:"
    echo "  (e.g. my-app-storage-bucket-12345)"
    echo ""
    read -p "   Bucket: " BUCKET_NAME
fi

if [ -z "$BUCKET_NAME" ]; then
    echo "  [ERROR] No bucket name provided."
    exit 1
fi

# ── AWS Profile (optional) ──
PROFILE="${2}"
if [ -z "$PROFILE" ]; then
    echo ""
    echo "  Enter AWS profile name (leave blank for default):"
    read -p "   Profile: " PROFILE
fi

PROFILE_ARG=""
if [ -n "$PROFILE" ]; then
    PROFILE_ARG="--profile $PROFILE"
fi

# ── Paths ──
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$SCRIPT_DIR/s3/protected/common/artifact"
S3_PATH="s3://$BUCKET_NAME/protected/common/artifact/"

echo ""
echo "  ────────────────────────────────────────────"
echo "  Bucket:  $BUCKET_NAME"
echo "  S3 path: $S3_PATH"
echo "  Local:   $TARGET_DIR"
[ -n "$PROFILE" ] && echo "  Profile: $PROFILE"
echo "  ────────────────────────────────────────────"
echo ""

# ── Dry run ──
echo "  [1/2] Previewing files to download (dry run)..."
echo ""
aws s3 sync "$S3_PATH" "$TARGET_DIR" --exclude "*" --include "*.jpg" --include "*.jpeg" --include "*.png" --dryrun $PROFILE_ARG

echo ""
echo "  ────────────────────────────────────────────"
read -p "   Proceed with download? (Y/N): " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo "  Download cancelled."
    exit 0
fi

# ── Download ──
echo ""
echo "  [2/2] Downloading images..."
echo ""
aws s3 sync "$S3_PATH" "$TARGET_DIR" --exclude "*" --include "*.jpg" --include "*.jpeg" --include "*.png" $PROFILE_ARG

if [ $? -eq 0 ]; then
    echo ""
    echo "  ============================================"
    echo "  [OK] Images downloaded successfully!"
    echo "  Location: $TARGET_DIR"
    echo "  ============================================"
    echo ""
    echo "  You can now generate PDFs with images:"
    echo "  node cli.mjs pdf couchdb.json --images ./s3"
    echo ""
else
    echo ""
    echo "  [ERROR] Download failed. Check your AWS credentials"
    echo "  and bucket name."
fi
