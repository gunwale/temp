// PDF Export — Pure ESM, no Babel needed
// Usage: source ~/.nvm/nvm.sh && nvm use 20 && node export_to_pdf.mjs

import fs from 'fs';
import { renderToFile } from '@react-pdf/renderer';
import { createReport } from './pdf/ReportBuilder.mjs';

// --- Flatten helpers (mirrored from export_to_excel.js) ---

function camelToTitle(str) {
    if (!str) return '';
    let res = str.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
    res = res.replace(/Id$/i, 'ID');
    res = res.replace(/^Arn$/i, 'ARN');
    return res;
}

function getColumnName(parentPath, key) {
    let cleanKey = camelToTitle(key);
    if (!parentPath) return cleanKey;
    if (parentPath === 'data') return cleanKey;
    if (parentPath.startsWith('data_')) {
        let pathWithoutData = parentPath.substring(5);
        let cleanPath = pathWithoutData.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    if (parentPath.startsWith('metadata')) {
        let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
    return `${cleanPath} ${cleanKey}`;
}

function flattenObject(ob, parentPath = '') {
    const toReturn = {};
    for (const i in ob) {
        if (!ob.hasOwnProperty(i)) continue;
        let newPath = parentPath ? parentPath + '_' + i : i;
        if ((typeof ob[i]) === 'object' && ob[i] !== null) {
            if (Array.isArray(ob[i])) {
                let str = JSON.stringify(ob[i]);
                if (str.length > 32000) str = str.substring(0, 32000) + '... [TRUNCATED]';
                toReturn[getColumnName(parentPath, i)] = str;
            } else {
                const flatObject = flattenObject(ob[i], newPath);
                for (const x in flatObject) {
                    if (!flatObject.hasOwnProperty(x)) continue;
                    toReturn[x] = flatObject[x];
                }
            }
        } else {
            let val = ob[i];
            if (typeof val === 'string' && val.length > 32000) {
                val = val.substring(0, 32000) + '... [TRUNCATED]';
            }
            toReturn[getColumnName(parentPath, i)] = val;
        }
    }
    return toReturn;
}

// --- Report Definitions ---

const reports = {
    artwork: {
        title: 'Artwork Catalog Report',
        subtitle: 'Complete inventory of non-gift artworks',
        orientation: 'landscape',
        columns: [
            { header: 'ARN',       key: 'ARN',              width: '12%' },
            { header: 'Title',     key: 'Title',             width: '20%' },
            { header: 'Artist',    key: 'Artist First Name', width: '12%' },
            { header: 'Category',  key: 'Art Category',      width: '12%' },
            { header: 'Medium',    key: 'Art Medium',        width: '14%' },
            { header: 'Status',    key: 'Metadata Status',   width: '10%' },
            { header: 'Location',  key: 'Location Building', width: '12%' },
            { header: 'Year',      key: 'Year',              width: '8%' },
        ],
    },
    gift: {
        title: 'Gift Catalog Report',
        subtitle: 'Complete inventory of gifted artworks',
        orientation: 'landscape',
        columns: [
            { header: 'ARN',        key: 'ARN',               width: '12%' },
            { header: 'Title',      key: 'Title',              width: '18%' },
            { header: 'Gifted By',  key: 'Gifted By',          width: '14%' },
            { header: 'Artist',     key: 'Artist First Name',  width: '12%' },
            { header: 'Category',   key: 'Art Category',       width: '12%' },
            { header: 'Status',     key: 'Metadata Status',    width: '10%' },
            { header: 'Location',   key: 'Location Building',  width: '12%' },
            { header: 'Year',       key: 'Year',               width: '10%' },
        ],
    },
    artist: {
        title: 'Artist Directory',
        subtitle: 'Complete listing of artists in the catalog',
        orientation: 'portrait',
        columns: [
            { header: 'Identifier', key: 'Identifier',   width: '25%' },
            { header: 'First Name', key: 'First Name',   width: '25%' },
            { header: 'Last Name',  key: 'Last Name',    width: '25%' },
            { header: 'Nickname',   key: 'Nick Name',    width: '25%' },
        ],
    },
    location: {
        title: 'Location Directory',
        subtitle: 'Complete listing of artwork locations',
        orientation: 'landscape',
        columns: [
            { header: 'Identifier',  key: 'Identifier',       width: '14%' },
            { header: 'Country',     key: 'Country ISO Code',  width: '10%' },
            { header: 'City',        key: 'City',              width: '12%' },
            { header: 'Building',    key: 'Building',          width: '16%' },
            { header: 'Floor',       key: 'Floor',             width: '8%' },
            { header: 'Room',        key: 'Room',              width: '10%' },
            { header: 'Office',      key: 'Office',            width: '14%' },
            { header: 'Address',     key: 'Address',           width: '16%' },
        ],
    },
};

// --- Main generation function ---

export async function generatePdf(inputFilePath, outputPrefix = 'couchdb') {
    console.log(`Loading ${inputFilePath}...`);
    const rawData = fs.readFileSync(inputFilePath, 'utf8');
    const data = JSON.parse(rawData);

    const collections = {};

    console.log('Processing documents...');
    for (const row of data.rows) {
        if (!row.doc) continue;
        const doc = row.doc;

        let docType = null;
        if (doc.metadata && doc.metadata.docType) docType = doc.metadata.docType;
        else if (doc.docType) docType = doc.docType;
        else if (doc.type) docType = doc.type;

        if (!docType || docType.startsWith('_design/')) continue;

        let isGift = false;
        if (doc.data && doc.data.isGift === true) isGift = true;

        delete doc._id;
        delete doc._rev;
        delete doc['~version'];
        delete doc._attachments;
        delete doc._conflicts;

        const flattenedDoc = flattenObject(doc);

        let sheetName = docType.replace('io.uob.resources.', '');
        if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

        let collectionName = sheetName;
        if (sheetName === 'artifact') {
            collectionName = isGift ? 'gift' : 'artwork';
        }

        if (!collections[collectionName]) collections[collectionName] = [];
        collections[collectionName].push(flattenedDoc);
    }

    // Generate PDFs
    for (const [entityName, config] of Object.entries(reports)) {
        const records = collections[entityName];
        if (!records || records.length === 0) {
            console.log(`  Skipping ${entityName} — no records found.`);
            continue;
        }

        const outputPath = `${outputPrefix}_${entityName}.pdf`;
        console.log(`Generating ${outputPath} (${records.length} records)...`);

        const doc = createReport(
            config.title,
            config.subtitle,
            config.columns,
            records,
            config.orientation,
        );
        await renderToFile(doc, outputPath);
        console.log(`  ✓ Written to ${outputPath}`);
    }

    console.log('PDF export completed successfully!');
}

// CLI entry point — only run when executed directly
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);

if (process.argv[1] === __filename) {
    const args = process.argv.slice(2);
    const inputFile = args[0] || 'couchdb.json';
    const prefix = args[1] || 'couchdb';

    generatePdf(inputFile, prefix).catch(err => {
        console.error('PDF generation failed:', err);
        process.exit(1);
    });
}
