@echo off
setlocal enabledelayedexpansion

echo.
echo   ============================================
echo   Data Extraction - Full Setup (No Admin)
echo   ============================================
echo.

set NODE_VER=20.12.2
set NODE_DIR=node-v%NODE_VER%-win-x64
set NODE_ZIP=%NODE_DIR%.zip
set NODE_URL=https://nodejs.org/dist/v%NODE_VER%/%NODE_ZIP%

:: ── Step 1: Check if Node.js is already available ──────────

where node >nul 2>nul
if %errorlevel%==0 (
    echo   [OK] Node.js already found in PATH.
    node --version
    goto :install_deps
)

:: Check if we already downloaded it locally
if exist "%~dp0%NODE_DIR%\node.exe" (
    echo   [OK] Local Node.js found.
    goto :set_path
)

:: ── Step 2: Download Node.js portable zip ──────────────────

echo   Node.js not found. Downloading portable version...
echo   URL: %NODE_URL%
echo.

:: Try curl first (available on Windows 10 1803+)
where curl >nul 2>nul
if %errorlevel%==0 (
    echo   Downloading with curl...
    curl -L -o "%~dp0%NODE_ZIP%" "%NODE_URL%"
    if %errorlevel%==0 goto :extract
    echo   curl download failed.
)

:: Fallback: bitsadmin (available on all Windows versions)
echo   Downloading with bitsadmin...
bitsadmin /transfer "NodeJS" /download /priority normal "%NODE_URL%" "%~dp0%NODE_ZIP%"
if %errorlevel%==0 goto :extract

:: Fallback: certutil
echo   Downloading with certutil...
certutil -urlcache -split -f "%NODE_URL%" "%~dp0%NODE_ZIP%"
if %errorlevel%==0 goto :extract

echo.
echo   [ERROR] Could not download Node.js automatically.
echo           Please download manually from:
echo           %NODE_URL%
echo           and extract into this folder.
echo.
pause
exit /b 1

:: ── Step 3: Extract zip ────────────────────────────────────

:extract
echo.
echo   Extracting %NODE_ZIP%...

:: Try tar first (available on Windows 10 1803+)
where tar >nul 2>nul
if %errorlevel%==0 (
    tar -xf "%~dp0%NODE_ZIP%" -C "%~dp0"
    if %errorlevel%==0 goto :cleanup_zip
)

:: Fallback: PowerShell extraction (non-interactive, no admin)
echo   Extracting with built-in tools...
powershell -NoProfile -NonInteractive -Command "Expand-Archive -Path '%~dp0%NODE_ZIP%' -DestinationPath '%~dp0' -Force" 2>nul
if %errorlevel%==0 goto :cleanup_zip

:: Fallback: VBScript extraction (works on very old Windows)
echo Set objShell = CreateObject("Shell.Application") > "%~dp0_unzip.vbs"
echo Set objSource = objShell.NameSpace("%~dp0%NODE_ZIP%") >> "%~dp0_unzip.vbs"
echo Set objTarget = objShell.NameSpace("%~dp0") >> "%~dp0_unzip.vbs"
echo objTarget.CopyHere objSource.Items, 256 >> "%~dp0_unzip.vbs"
cscript //nologo "%~dp0_unzip.vbs"
del "%~dp0_unzip.vbs"

:cleanup_zip
if exist "%~dp0%NODE_ZIP%" del "%~dp0%NODE_ZIP%"

if not exist "%~dp0%NODE_DIR%\node.exe" (
    echo.
    echo   [ERROR] Extraction failed.
    echo           Please extract %NODE_ZIP% manually into this folder.
    pause
    exit /b 1
)

echo   [OK] Node.js extracted to %NODE_DIR%

:: ── Step 4: Set local PATH ─────────────────────────────────

:set_path
set "PATH=%~dp0%NODE_DIR%;%PATH%"
echo   [OK] Node.js v%NODE_VER% ready.
node --version

:: ── Step 5: Install npm dependencies ───────────────────────

:install_deps
echo.
echo   Installing npm dependencies...
echo.
cd /d "%~dp0"
call npm install
echo.

if %errorlevel%==0 (
    echo   ============================================
    echo   Setup complete!
    echo   ============================================
    echo.
    echo   Use run.bat to start the tool.
) else (
    echo   [ERROR] npm install failed.
)

echo.
pause
