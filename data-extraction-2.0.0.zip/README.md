# Data Extraction CLI

Export CouchDB data to Excel workbooks and PDF artwork catalogs.

## Requirements

- Node.js 18+ (https://nodejs.org)

## Quick Start

### Windows (CMD — no PowerShell needed)

1. Double-click `install.bat` (one-time setup)
2. Double-click `run.bat` and follow the menu

Or from CMD:
```
run.bat excel couchdb.json
run.bat pdf couchdb.json
```

### Mac / Linux

```bash
./install.sh          # one-time setup
./run.sh              # interactive menu
```

Or directly:
```bash
./run.sh excel couchdb.json
./run.sh pdf couchdb.json -o catalog.pdf --images ./assets
```

## Commands

| Command | Description |
|---------|-------------|
| `excel <file>` | Export all entities to separate `.xlsx` workbooks |
| `pdf <file>` | Generate artwork catalog PDF (one page per artwork) |
| `help` | Show full usage |

## Options

| Option | Applies to | Description |
|--------|-----------|-------------|
| `-o, --output` | excel | Output filename prefix (default: `export`) |
| `-o, --output` | pdf | Output PDF filename (default: `artwork_catalog.pdf`) |
| `--images <dir>` | pdf | Local directory mirroring S3 image paths |

## Image Directory

If you have artwork images downloaded from S3, pass `--images <dir>`.
The tool resolves S3 paths relative to that directory:

```
<dir>/protected/common/artifact/SG/xxx.jpg
```
