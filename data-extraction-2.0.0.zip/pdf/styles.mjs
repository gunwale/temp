import { StyleSheet } from '@react-pdf/renderer';

export const colors = {
    primary: '#1A237E',
    primaryLight: '#3949AB',
    tableHeaderBg: '#E8EAF6',
    tableHeaderText: '#1A237E',
    rowEven: '#FFFFFF',
    rowOdd: '#F5F5F5',
    border: '#C5CAE9',
    text: '#212121',
    textLight: '#757575',
};

export const styles = StyleSheet.create({
    page: {
        padding: 30,
        fontSize: 8,
        fontFamily: 'Helvetica',
        backgroundColor: '#FFFFFF',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
        paddingBottom: 10,
        borderBottomWidth: 2,
        borderBottomColor: colors.primary,
    },
    headerTitle: {
        fontSize: 18,
        fontFamily: 'Helvetica-Bold',
        color: colors.primary,
    },
    headerSubtitle: {
        fontSize: 9,
        color: colors.textLight,
        marginTop: 2,
    },
    headerRight: {
        alignItems: 'flex-end',
    },
    headerDate: {
        fontSize: 8,
        color: colors.textLight,
    },
    headerCount: {
        fontSize: 9,
        fontFamily: 'Helvetica-Bold',
        color: colors.primaryLight,
        marginTop: 2,
    },
    tableRow: {
        flexDirection: 'row',
        minHeight: 18,
        alignItems: 'center',
    },
    tableRowEven: {
        backgroundColor: colors.rowEven,
    },
    tableRowOdd: {
        backgroundColor: colors.rowOdd,
    },
    tableHeaderRow: {
        flexDirection: 'row',
        minHeight: 22,
        alignItems: 'center',
        backgroundColor: colors.tableHeaderBg,
        borderBottomWidth: 1,
        borderBottomColor: colors.primary,
    },
    tableHeaderCell: {
        fontFamily: 'Helvetica-Bold',
        fontSize: 7,
        color: colors.tableHeaderText,
        padding: 4,
        textTransform: 'uppercase',
    },
    tableCell: {
        fontSize: 7,
        color: colors.text,
        padding: 4,
        overflow: 'hidden',
    },
    footer: {
        position: 'absolute',
        bottom: 15,
        left: 30,
        right: 30,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: 6,
        borderTopWidth: 1,
        borderTopColor: colors.border,
    },
    footerText: {
        fontSize: 7,
        color: colors.textLight,
    },
    footerPage: {
        fontSize: 7,
        color: colors.textLight,
    },
});
