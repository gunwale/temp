import React from 'react';
import { Document, Page, Text, View, Image, StyleSheet } from '@react-pdf/renderer';

const colors = {
    primary: '#1A237E',
    primaryLight: '#3949AB',
    accent: '#C5CAE9',
    sectionBg: '#F5F7FA',
    text: '#212121',
    textLight: '#757575',
    label: '#546E7A',
    border: '#E0E0E0',
    white: '#FFFFFF',
};

const styles = StyleSheet.create({
    page: {
        padding: 30,
        fontFamily: 'Helvetica',
        backgroundColor: colors.white,
    },
    // ── Header bar ──
    headerBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingBottom: 8,
        borderBottomWidth: 2,
        borderBottomColor: colors.primary,
        marginBottom: 12,
    },
    headerArn: {
        fontSize: 14,
        fontFamily: 'Helvetica-Bold',
        color: colors.primary,
    },
    headerTitle: {
        fontSize: 11,
        color: colors.text,
        maxWidth: '70%',
    },
    // ── Main layout: image left, details right ──
    mainRow: {
        flexDirection: 'row',
        gap: 15,
        marginBottom: 12,
    },
    imageContainer: {
        width: '40%',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    artImage: {
        maxWidth: '100%',
        maxHeight: 280,
        objectFit: 'contain',
    },
    imagePlaceholder: {
        width: '100%',
        height: 200,
        backgroundColor: '#F0F0F0',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: colors.border,
        borderStyle: 'dashed',
    },
    imagePlaceholderText: {
        fontSize: 9,
        color: colors.textLight,
    },
    detailsColumn: {
        width: '58%',
    },
    // ── Section ──
    section: {
        marginBottom: 10,
    },
    sectionTitle: {
        fontSize: 9,
        fontFamily: 'Helvetica-Bold',
        color: colors.primary,
        textTransform: 'uppercase',
        letterSpacing: 0.8,
        marginBottom: 4,
        paddingBottom: 2,
        borderBottomWidth: 1,
        borderBottomColor: colors.accent,
    },
    // ── Field rows ──
    fieldRow: {
        flexDirection: 'row',
        paddingVertical: 2,
    },
    fieldLabel: {
        width: '40%',
        fontSize: 8,
        fontFamily: 'Helvetica-Bold',
        color: colors.label,
    },
    fieldValue: {
        width: '60%',
        fontSize: 8,
        color: colors.text,
    },
    // ── Full-width sections ──
    fullWidthSection: {
        marginBottom: 10,
    },
    gridRow: {
        flexDirection: 'row',
        gap: 15,
    },
    gridCol: {
        width: '48%',
    },
    // ── Footer ──
    footer: {
        position: 'absolute',
        bottom: 15,
        left: 30,
        right: 30,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: 4,
        borderTopWidth: 1,
        borderTopColor: colors.border,
    },
    footerText: {
        fontSize: 7,
        color: colors.textLight,
    },
});

const h = React.createElement;

function Field({ label, value }) {
    if (value == null || value === '' || value === '-' || value === 'undefined') return null;
    return h(View, { style: styles.fieldRow },
        h(Text, { style: styles.fieldLabel }, label),
        h(Text, { style: styles.fieldValue }, String(value)),
    );
}

function Section({ title, children }) {
    return h(View, { style: styles.section },
        h(Text, { style: styles.sectionTitle }, title),
        children,
    );
}

function formatDate(dateStr) {
    if (!dateStr) return null;
    try {
        const d = new Date(dateStr);
        if (isNaN(d.getTime())) return dateStr;
        return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch { return dateStr; }
}

export function createArtworkPage(doc, imagePath, catalogTitle = 'Art Catalog') {
    const d = doc.data || {};
    const loc = d.location || {};
    const artist = d.artist || {};

    const imageEl = imagePath
        ? h(Image, { src: imagePath, style: styles.artImage })
        : h(View, { style: styles.imagePlaceholder },
            h(Text, { style: styles.imagePlaceholderText }, 'No Image Available'),
        );

    return h(Page, { size: 'A4', style: styles.page, key: d.arn || doc.identifier },
        // ── Header ──
        h(View, { style: styles.headerBar },
            h(Text, { style: styles.headerArn }, d.arn || 'N/A'),
            h(Text, { style: styles.headerTitle }, d.title || 'Untitled'),
        ),

        // ── Main row: image + core details ──
        h(View, { style: styles.mainRow },
            h(View, { style: styles.imageContainer }, imageEl),
            h(View, { style: styles.detailsColumn },
                // Artist
                h(Section, { title: 'Artist' },
                    h(Field, { label: 'Name', value: artist.nickName }),
                    h(Field, { label: 'Identifier', value: artist.identifier }),
                ),
                // Classification
                h(Section, { title: 'Classification' },
                    h(Field, { label: 'Category', value: d.artCategory }),
                    h(Field, { label: 'Medium', value: d.artMedium }),
                    h(Field, { label: 'Orientation', value: d.artOrientation }),
                    h(Field, { label: 'Status', value: d.status }),
                    h(Field, { label: 'Year', value: formatDate(d.year) }),
                    h(Field, { label: 'Tags', value: d.artTags }),
                ),
                // Company
                h(Section, { title: 'Company' },
                    h(Field, { label: 'Company', value: d.company }),
                    h(Field, { label: 'Co Code', value: d.coCode }),
                    h(Field, { label: 'Acquisition Date', value: formatDate(d.acquisitionDate) }),
                    h(Field, { label: 'Gifted By', value: d.giftedBy }),
                ),
            ),
        ),

        // ── Full-width sections: 2-column grid ──
        h(View, { style: styles.gridRow },
            // Left: Dimensions
            h(View, { style: styles.gridCol },
                h(Section, { title: 'Dimensions (cm)' },
                    h(Field, { label: 'Height', value: d.artHeight }),
                    h(Field, { label: 'Width', value: d.artWidth }),
                    h(Field, { label: 'Depth', value: d.artDepth }),
                    h(Field, { label: 'Frame Height', value: d.artFrameHeight }),
                    h(Field, { label: 'Frame Width', value: d.artFrameWidth }),
                    h(Field, { label: 'Frame Depth', value: d.artFrameDepth }),
                ),
            ),
            // Right: Condition
            h(View, { style: styles.gridCol },
                h(Section, { title: 'Condition' },
                    h(Field, { label: 'Art Condition', value: d.artCondition }),
                    h(Field, { label: 'Condition Notes', value: d.artConditionComment }),
                    h(Field, { label: 'Frame Condition', value: d.artFrameCondition }),
                    h(Field, { label: 'Mount Condition', value: d.artMountCondition }),
                ),
            ),
        ),

        // Valuation
        h(View, { style: styles.fullWidthSection },
            h(Section, { title: 'Valuation' },
                h(View, { style: styles.gridRow },
                    h(View, { style: styles.gridCol },
                        h(Field, { label: 'Min Value', value: d.artMinValue }),
                        h(Field, { label: 'Max Value', value: d.artMaxValue }),
                    ),
                    h(View, { style: styles.gridCol },
                        h(Field, { label: 'Valued By', value: d.artValuedBy }),
                        h(Field, { label: 'Valued Date', value: formatDate(d.artValuedDate) }),
                        h(Field, { label: 'Valuation Notes', value: d.artValuationNotes }),
                    ),
                ),
            ),
        ),

        // Location
        h(View, { style: styles.fullWidthSection },
            h(Section, { title: 'Location' },
                h(View, { style: styles.gridRow },
                    h(View, { style: styles.gridCol },
                        h(Field, { label: 'Building', value: loc.building }),
                        h(Field, { label: 'Floor', value: loc.floor }),
                        h(Field, { label: 'Room', value: loc.room }),
                        h(Field, { label: 'Office', value: loc.office }),
                    ),
                    h(View, { style: styles.gridCol },
                        h(Field, { label: 'Address', value: loc.address }),
                        h(Field, { label: 'City', value: loc.city }),
                        h(Field, { label: 'Country', value: loc.countryISOCode }),
                        h(Field, { label: 'Postal Code', value: loc.postalCode }),
                    ),
                ),
            ),
        ),

        // Descriptions
        h(View, { style: styles.fullWidthSection },
            h(Section, { title: 'Description' },
                h(Field, { label: 'Writeup', value: d.artworkWriteup }),
                h(Field, { label: 'Descriptive Notes', value: d.descriptiveNotes }),
                h(Field, { label: 'Awards', value: d.artworkAwards }),
                h(Field, { label: 'Curated Tags', value: d.curatedTags }),
            ),
        ),

        // Footer
        h(View, { style: styles.footer, fixed: true },
            h(Text, { style: styles.footerText }, `${catalogTitle} — Data Extraction`),
            h(Text, {
                style: styles.footerText,
                render: ({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`,
            }),
        ),
    );
}

export function createArtworkCatalog(artworks, imageResolver, catalogTitle = 'Art Catalog') {
    const pages = artworks.map(doc => {
        const imagePath = imageResolver ? imageResolver(doc) : null;
        return createArtworkPage(doc, imagePath, catalogTitle);
    });

    return h(Document, null, ...pages);
}
