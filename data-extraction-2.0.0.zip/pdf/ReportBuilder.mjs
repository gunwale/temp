import React from 'react';
import { Document, Page, Text, View } from '@react-pdf/renderer';
import { styles } from './styles.mjs';

const h = React.createElement;

/**
 * Creates a tabular PDF report document.
 * @param {string} title - Report title
 * @param {string} subtitle - Report subtitle
 * @param {Array<{header: string, key: string, width: string}>} columns - Column definitions
 * @param {Array<Object>} data - Flattened data rows
 * @param {string} orientation - 'portrait' or 'landscape'
 * @returns React element
 */
export function createReport(title, subtitle, columns, data, orientation = 'landscape') {
    const generatedAt = new Date().toLocaleDateString('en-GB', {
        day: '2-digit', month: 'short', year: 'numeric',
    });

    // Header
    const header = h(View, { style: styles.header, fixed: true },
        h(View, null,
            h(Text, { style: styles.headerTitle }, title),
            h(Text, { style: styles.headerSubtitle }, subtitle),
        ),
        h(View, { style: styles.headerRight },
            h(Text, { style: styles.headerDate }, `Generated: ${generatedAt}`),
            h(Text, { style: styles.headerCount }, `${data.length} Records`),
        ),
    );

    // Table header row
    const tableHeader = h(View, { style: styles.tableHeaderRow, fixed: true },
        ...columns.map(col =>
            h(View, { key: col.key, style: { width: col.width } },
                h(Text, { style: styles.tableHeaderCell }, col.header),
            ),
        ),
    );

    // Table body rows
    const tableRows = data.map((row, i) =>
        h(View, {
            key: i,
            style: [styles.tableRow, i % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd],
            wrap: false,
        },
            ...columns.map(col =>
                h(View, { key: col.key, style: { width: col.width } },
                    h(Text, { style: styles.tableCell },
                        row[col.key] != null ? String(row[col.key]).substring(0, 60) : '',
                    ),
                ),
            ),
        ),
    );

    // Footer
    const footer = h(View, { style: styles.footer, fixed: true },
        h(Text, { style: styles.footerText }, 'Art Catalog Data Extraction'),
        h(Text, {
            style: styles.footerPage,
            render: ({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`,
        }),
    );

    return h(Document, null,
        h(Page, { size: 'A4', orientation, style: styles.page },
            header,
            tableHeader,
            ...tableRows,
            footer,
        ),
    );
}
