#!/bin/bash
echo ""
echo "  ================================"
echo "  Data Extraction - Setup"
echo "  ================================"
echo ""
echo "  Installing dependencies..."
echo ""
npm install
echo ""
echo "  Setup complete!"
echo "  You can now use ./run.sh"
echo ""
