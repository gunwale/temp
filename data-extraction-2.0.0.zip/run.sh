#!/bin/bash

if [ $# -gt 0 ]; then
    node cli.mjs "$@"
    exit 0
fi

echo ""
echo "  ================================"
echo "  Data Extraction CLI"
echo "  ================================"
echo ""
echo "  What would you like to do?"
echo ""
echo "    1. Export to Excel"
echo "    2. Export to PDF (artwork catalog)"
echo "    3. Show help"
echo "    0. Exit"
echo ""
read -p "  Enter choice (0-3): " choice

case $choice in
    0) exit 0 ;;
    3) node cli.mjs help ;;
    1)
        read -p "  Path to couchdb.json: " inputfile
        read -p "  Output prefix (or press Enter for 'export'): " prefix
        prefix=${prefix:-export}
        echo ""
        node cli.mjs excel "$inputfile" -o "$prefix"
        ;;
    2)
        read -p "  Path to couchdb.json: " inputfile
        read -p "  Output PDF name (or press Enter for 'artwork_catalog.pdf'): " outfile
        outfile=${outfile:-artwork_catalog.pdf}
        read -p "  Image directory (or press Enter to skip): " imgdir
        echo ""
        if [ -z "$imgdir" ]; then
            node cli.mjs pdf "$inputfile" -o "$outfile"
        else
            node cli.mjs pdf "$inputfile" -o "$outfile" --images "$imgdir"
        fi
        ;;
    *) echo "  Invalid choice." ;;
esac
