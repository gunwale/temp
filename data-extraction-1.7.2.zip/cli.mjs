#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════════
//  Data Extraction CLI
//  Export CouchDB data to Excel workbooks or PDF catalog
//  Requires Node 18+
// ═══════════════════════════════════════════════════════════════

// ── Auto-configure memory limits ──────────────────────────────
// Re-spawn with 6 GB heap + GC access if not already set
const MAX_HEAP_MB = 6144;
if (!process.env.__CLI_MEM_SET) {
    const { execFileSync } = await import('child_process');
    try {
        execFileSync(process.execPath, [
            `--max-old-space-size=${MAX_HEAP_MB}`,
            '--expose-gc',
            ...process.argv.slice(1),
        ], {
            stdio: 'inherit',
            env: { ...process.env, __CLI_MEM_SET: '1' },
        });
    } catch (e) {
        process.exit(e.status || 1);
    }
    process.exit(0);
}

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// ══════════════════════════════════════════════════════════════
//  Help
// ══════════════════════════════════════════════════════════════

function printHelp() {
    console.log(`
  ┌──────────────────────────────────────────────┐
  │  Data Extraction CLI                         │
  │  Export CouchDB data to Excel & PDF          │
  └──────────────────────────────────────────────┘

  Usage:
    node cli.mjs <command> <input> [options]

  Commands:
    excel <file>          Export all entities to separate Excel workbooks
    pdf <file>            Generate artwork catalog PDF (one page per artwork)
    locations <file>      Extract unique buildings & ARN location patch CSV
    diff <file>           Run both diff-new and diff-updates
    diff-new <file>       Find new/removed ARNs (masterlist vs CouchDB)
    diff-updates <file>   Find updated fields for existing ARNs
    patch <file>          Apply masterlist updates into CouchDB JSON (add/update, no remove)
    help                  Show this help message

  Arguments:
    <file>          Path to couchdb.json or couchdb.txt

  Options (excel):
    -o, --output <prefix>   Output filename prefix (default: "export")

  Options (pdf):
    -o, --output <path>     Output PDF filename (default: "artwork_catalog.pdf")
    --images <dir>          Local image directory mirroring S3 paths
                            Images are resolved as: <dir>/<s3_path>
                            e.g. --images ./assets will look for
                            ./assets/protected/common/artifact/SG/xxx.jpg

  Options (locations):
    -o, --output <prefix>   Output filename prefix (default: "sg")
    --country <name>        Filter by country (default: "Singapore")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")

  Options (diff, diff-new, diff-updates):
    --masterlist <xlsx>     Path to the masterlist Excel file (required)
    -o, --output <prefix>   Output filename prefix (default: "diff")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")

  Output files (diff-updates):
    <prefix>_building_moves.csv
        Cross-building moves: ARNs where the building name differs between
        CouchDB and the masterlist after noise normalization.
        Columns: ARN, Title, Artist, CouchDB Building, Masterlist Building,
                 CouchDB Office, Masterlist Office,
                 CouchDB Floor, Masterlist Floor, CouchDB Room, Masterlist Room

    <prefix>_within_building_moves.csv
        Within-building moves: ARNs in the same building where sub-location
        fields (Office, Floor, Room, Address, Postal Code) differ.
        Columns: ARN, Title, Artist, Building Name, Changed Fields,
                 CouchDB Office, Masterlist Office,
                 CouchDB Floor, Masterlist Floor, CouchDB Room, Masterlist Room

  Denoise rules applied to all location comparisons:
    - Leading Excel apostrophes and curly/straight quotes stripped
    - Numeric leading zeros stripped: "01" -> "1"
    - Floor prefix keywords stripped: "Level 3" -> "3"
    - Spaces around slashes normalised: "A/ B" -> "A/B"
    - Building names: abbreviations expanded (Bldg, Blk, Ctr, St, Rd, etc.),
      slashes/dashes/ampersands treated as spaces

  Options (patch):
    --masterlist <xlsx>     Path to the masterlist Excel file (required)
    -o, --output <path>     Output JSON filename (default: "patched_couchdb.json")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")
    --dry-run               Print summary only, do not write output file

  Output file (patch):
    <output>.json
        A copy of the CouchDB JSON with masterlist location data merged in.
        Rules:
          • Existing ARNs — location object overwritten with masterlist values
            (building, office, floor, room, address, postalCode, countryISOCode).
            All other CouchDB fields are left untouched.
          • New ARNs (in masterlist only) — full record added including all
            masterlist fields (title, status, medium, category, entity, location).
          • CouchDB-only ARNs — never removed.

  Examples:
    node cli.mjs help
    node cli.mjs excel ./couchdb.json
    node cli.mjs pdf ./couchdb.json -o report.pdf --images ./s3_mirror
    node cli.mjs locations ./couchdb.json --target artwork
    node cli.mjs locations ./couchdb.json --country Thailand -o th
    node cli.mjs diff ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork
    node cli.mjs diff-new ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork
    node cli.mjs diff-updates ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork -o sg_artwork
    node cli.mjs diff-updates ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target gift -o sg_gift
    node cli.mjs patch ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork -o patched.json
    node cli.mjs patch ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --dry-run
`);
}

// ══════════════════════════════════════════════════════════════
//  Argument Parsing
// ══════════════════════════════════════════════════════════════

function parseArgs(argv) {
    const args = argv.slice(2);

    if (args.length === 0 || args[0] === 'help' || args.includes('-h') || args.includes('--help')) {
        printHelp();
        process.exit(0);
    }

    const command = args[0];
    if (!['excel', 'pdf', 'locations', 'diff', 'diff-new', 'diff-updates', 'patch'].includes(command)) {
        console.error(`\n  ❌ Unknown command "${command}". Use "excel", "pdf", "locations", "diff", "diff-new", "diff-updates", "patch", or "help".\n`);
        process.exit(1);
    }

    const input = args[1];
    if (!input) {
        console.error(`\n  ❌ Missing input file. Usage: node cli.mjs ${command} <couchdb.json>\n`);
        process.exit(1);
    }

    const resolvedInput = path.resolve(input);
    if (!fs.existsSync(resolvedInput)) {
        console.error(`\n  ❌ File not found: ${resolvedInput}\n`);
        process.exit(1);
    }

    const parsed = { command, input: resolvedInput, output: null, images: null, country: 'Singapore', masterlist: null, target: 'all', dryRun: false };

    // Defaults
    if (command === 'excel') parsed.output = 'export';
    if (command === 'pdf') parsed.output = 'artwork_catalog.pdf';
    if (command === 'locations') parsed.output = 'sg';
    if (command === 'diff' || command === 'diff-new' || command === 'diff-updates') parsed.output = 'diff';
    if (command === 'patch') parsed.output = 'patched_couchdb.json';

    // Parse remaining options
    for (let i = 2; i < args.length; i++) {
        switch (args[i]) {
            case '-o':
            case '--output':
                parsed.output = args[++i];
                break;
            case '--images':
                parsed.images = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.images)) {
                    console.error(`\n  ❌ Images directory not found: ${parsed.images}\n`);
                    process.exit(1);
                }
                break;
            case '--country':
                parsed.country = args[++i];
                break;
            case '--masterlist':
                parsed.masterlist = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.masterlist)) {
                    console.error(`\n  ❌ Masterlist file not found: ${parsed.masterlist}\n`);
                    process.exit(1);
                }
                break;
            case '--dry-run':
                parsed.dryRun = true;
                break;
            case '--target':
                parsed.target = args[++i]?.toLowerCase();
                if (!['artwork', 'gift', 'all'].includes(parsed.target)) {
                    console.error(`\n  ❌ Invalid target "${parsed.target}". Use "artwork", "gift", or "all".\n`);
                    process.exit(1);
                }
                break;
            default:
                console.error(`\n  ❌ Unknown option "${args[i]}". Run "node cli.mjs help" for usage.\n`);
                process.exit(1);
        }
    }

    return parsed;
}

// ══════════════════════════════════════════════════════════════
//  Flatten Helpers
// ══════════════════════════════════════════════════════════════

function camelToTitle(str) {
    if (!str) return '';
    let res = str.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
    res = res.replace(/Id$/i, 'ID');
    res = res.replace(/^Arn$/i, 'ARN');
    return res;
}

function getColumnName(parentPath, key) {
    let cleanKey = camelToTitle(key);
    if (!parentPath) return cleanKey;
    if (parentPath === 'data') return cleanKey;
    if (parentPath.startsWith('data_')) {
        let cleanPath = parentPath.substring(5).split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    if (parentPath.startsWith('metadata')) {
        let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
    return `${cleanPath} ${cleanKey}`;
}

function flattenObject(ob, parentPath = '') {
    const toReturn = {};
    for (const i in ob) {
        if (!ob.hasOwnProperty(i)) continue;
        let newPath = parentPath ? parentPath + '_' + i : i;
        if ((typeof ob[i]) === 'object' && ob[i] !== null) {
            if (Array.isArray(ob[i])) {
                let str = JSON.stringify(ob[i]);
                if (str.length > 32000) str = str.substring(0, 32000) + '... [TRUNCATED]';
                toReturn[getColumnName(parentPath, i)] = str;
            } else {
                const flatObject = flattenObject(ob[i], newPath);
                for (const x in flatObject) {
                    if (!flatObject.hasOwnProperty(x)) continue;
                    toReturn[x] = flatObject[x];
                }
            }
        } else {
            let val = ob[i];
            if (typeof val === 'string' && val.length > 32000) {
                val = val.substring(0, 32000) + '... [TRUNCATED]';
            }
            toReturn[getColumnName(parentPath, i)] = val;
        }
    }
    return toReturn;
}

// ══════════════════════════════════════════════════════════════
//  Data Loading
// ══════════════════════════════════════════════════════════════

function loadDocuments(inputFilePath) {
    console.log(`\n  📂 Loading ${inputFilePath}...`);
    const rawData = fs.readFileSync(inputFilePath, 'utf8');
    const data = JSON.parse(rawData);
    return data.rows.filter(r => r.doc).map(r => r.doc);
}

function categorizeDocuments(docs) {
    const collections = {};      // for Excel (flattened)
    const rawCollections = {};   // for PDF (raw docs)

    for (const doc of docs) {
        let docType = null;
        if (doc.metadata && doc.metadata.docType) docType = doc.metadata.docType;
        else if (doc.docType) docType = doc.docType;
        else if (doc.type) docType = doc.type;
        if (!docType || docType.startsWith('_design/')) continue;

        let isGift = doc.data && doc.data.isGift === true;

        // Clone for flattening (we strip internal fields)
        const docCopy = JSON.parse(JSON.stringify(doc));
        delete docCopy._id;
        delete docCopy._rev;
        delete docCopy['~version'];
        delete docCopy._attachments;
        delete docCopy._conflicts;

        const flattenedDoc = flattenObject(docCopy);

        let sheetName = docType.replace('io.uob.resources.', '');
        if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

        let collectionName = sheetName;
        if (sheetName === 'artifact') {
            collectionName = isGift ? 'gift' : 'artwork';
        }

        if (!collections[collectionName]) collections[collectionName] = [];
        collections[collectionName].push(flattenedDoc);

        if (!rawCollections[collectionName]) rawCollections[collectionName] = [];
        rawCollections[collectionName].push(doc);
    }

    return { collections, rawCollections };
}

// ══════════════════════════════════════════════════════════════
//  Excel Export
// ══════════════════════════════════════════════════════════════

function runExcel(opts) {
    const docs = loadDocuments(opts.input);
    const { collections } = categorizeDocuments(docs);

    console.log(`  ✓ Found ${Object.keys(collections).length} collections\n`);

    const xlsx = require('xlsx');
    let count = 0;

    for (const [name, records] of Object.entries(collections)) {
        const fileName = `${opts.output}_${name}.xlsx`;
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(records);
        let safeSheet = name.length > 31 ? name.substring(0, 31) : name;
        xlsx.utils.book_append_sheet(wb, ws, safeSheet);
        xlsx.writeFile(wb, fileName);
        console.log(`  📊 ${fileName}  (${records.length} records)`);
        count++;
    }

    console.log(`\n  ✅ ${count} Excel file(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  PDF Export — Artwork Catalog
// ══════════════════════════════════════════════════════════════

const IMAGE_MAX_PX = 800;    // max dimension (width or height)
const IMAGE_QUALITY = 75;    // JPEG quality (1-100)
const CACHE_DIR = path.join(__dirname, '.image_cache');

/**
 * Resolve the original image path for a document.
 * Tries URL-encoded path first, then decoded fallback.
 */
function resolveOriginalImage(imagesDir, doc) {
    const images = doc.data && doc.data.images;
    if (!images || images.length === 0) return null;
    const imgUrl = images[0].url;

    // Try literal path (URL-encoded folder names)
    const localPath = path.join(imagesDir, imgUrl);
    if (fs.existsSync(localPath)) return localPath;

    // Fallback: URL-decoded path (e.g. %20 → space)
    try {
        const decodedUrl = decodeURIComponent(imgUrl);
        if (decodedUrl !== imgUrl) {
            const decodedPath = path.join(imagesDir, decodedUrl);
            if (fs.existsSync(decodedPath)) return decodedPath;
        }
    } catch { /* ignore decode errors */ }
    return null;
}

/**
 * Pre-process images: resize + compress into .image_cache/
 * Returns a Map<docArn, cachedPath>
 */
async function preprocessImages(docs, imagesDir) {
    const sharp = (await import('sharp')).default;

    if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });

    const imageMap = new Map();
    let processed = 0;
    let skipped = 0;
    const missingList = [];

    for (const doc of docs) {
        const arn = doc.data?.arn || doc.identifier || '';
        const originalPath = resolveOriginalImage(imagesDir, doc);
        if (!originalPath) {
            // Record expected path for debugging
            const imgUrl = doc.data?.images?.[0]?.url;
            const expectedPath = imgUrl ? path.join(imagesDir, imgUrl) : null;
            missingList.push({ arn, expectedPath });
            continue;
        }

        // Cache key: use a safe filename from the original
        const ext = path.extname(originalPath).toLowerCase();
        const baseName = path.basename(originalPath, ext);
        const cachedPath = path.join(CACHE_DIR, `${baseName}_thumb.jpg`);

        // Skip if already cached
        if (fs.existsSync(cachedPath)) {
            imageMap.set(arn, cachedPath);
            skipped++;
            continue;
        }

        try {
            await sharp(originalPath)
                .resize(IMAGE_MAX_PX, IMAGE_MAX_PX, { fit: 'inside', withoutEnlargement: true })
                .jpeg({ quality: IMAGE_QUALITY, mozjpeg: true })
                .toFile(cachedPath);
            imageMap.set(arn, cachedPath);
            processed++;
        } catch (err) {
            console.error(`  ⚠  Failed to process ${path.basename(originalPath)}: ${err.message}`);
        }
    }

    console.log(`  🖼  Images: ${processed} resized, ${skipped} cached, ${missingList.length} not found`);

    // Show first 5 missing paths as examples
    if (missingList.length > 0) {
        const show = missingList.slice(0, 5);
        show.forEach(m => {
            console.log(`     ✗ ${m.arn} → ${m.expectedPath || '(no image URL)'}`);
        });
        if (missingList.length > 5) {
            console.log(`     ... and ${missingList.length - 5} more`);
        }
        // Write full list to log file
        const logPath = path.join(__dirname, 'missing_images.log');
        const logLines = missingList.map(m => `${m.arn}\t${m.expectedPath || 'N/A'}`).join('\n');
        fs.writeFileSync(logPath, logLines + '\n');
        console.log(`  📝 Full list saved to missing_images.log`);
    }

    return imageMap;
}

const CHUNK_SIZE = 100;  // pages per rendering batch (lower = less RAM)

/**
 * Render a collection in chunks and merge into a single PDF.
 * This keeps peak memory proportional to CHUNK_SIZE instead of total pages.
 */
async function renderChunked(docs, imageResolver, outputPath, catalogTitle) {
    const { renderToFile } = await import('@react-pdf/renderer');
    const { createArtworkCatalog } = await import('./pdf/ArtworkCatalog.mjs');
    const { PDFDocument } = await import('pdf-lib');

    const totalPages = docs.length;
    const totalChunks = Math.ceil(totalPages / CHUNK_SIZE);

    // If small enough, render directly (no chunking overhead)
    if (totalPages <= CHUNK_SIZE) {
        console.log(`  ⏳ Rendering ${totalPages} pages to ${outputPath}...`);
        const catalog = createArtworkCatalog(docs, imageResolver, catalogTitle);
        await renderToFile(catalog, outputPath);
        console.log(`  ✓ ${outputPath}`);
        return;
    }

    console.log(`  ⏳ Rendering ${totalPages} pages in ${totalChunks} chunks (${CHUNK_SIZE}/chunk) to ${outputPath}...`);

    const tempDir = path.join(__dirname, '.pdf_temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const tempFiles = [];

    for (let i = 0; i < totalChunks; i++) {
        const start = i * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, totalPages);
        const chunk = docs.slice(start, end);
        const tempFile = path.join(tempDir, `chunk_${i}.pdf`);

        const heapMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(0);
        console.log(`     chunk ${i + 1}/${totalChunks} (pages ${start + 1}–${end}) [heap: ${heapMB} MB]`);
        const catalog = createArtworkCatalog(chunk, imageResolver, catalogTitle);
        await renderToFile(catalog, tempFile);
        tempFiles.push(tempFile);

        // Force GC between chunks to free memory
        if (global.gc) global.gc();
    }

    // Merge all chunks with pdf-lib
    console.log(`  📎 Merging ${totalChunks} chunks...`);
    const mergedPdf = await PDFDocument.create();

    for (const tempFile of tempFiles) {
        const chunkBytes = fs.readFileSync(tempFile);
        const chunkPdf = await PDFDocument.load(chunkBytes);
        const pages = await mergedPdf.copyPages(chunkPdf, chunkPdf.getPageIndices());
        pages.forEach(page => mergedPdf.addPage(page));
    }

    const mergedBytes = await mergedPdf.save();
    fs.writeFileSync(outputPath, mergedBytes);

    // Cleanup temp files
    for (const f of tempFiles) fs.unlinkSync(f);
    fs.rmSync(tempDir, { recursive: true });

    console.log(`  ✓ ${outputPath} (${totalPages} pages)`);
}

async function runPdf(opts) {
    let docs = loadDocuments(opts.input);
    const { rawCollections } = categorizeDocuments(docs);

    // Free raw docs array to reclaim ~130 MB
    docs = null;
    if (global.gc) global.gc();

    const artworks = rawCollections.artwork || [];
    const gifts = rawCollections.gift || [];

    if (artworks.length === 0 && gifts.length === 0) {
        console.error('\n  ❌ No artwork or gift records found in the input file.\n');
        process.exit(1);
    }

    console.log(`  ✓ Found ${artworks.length} artworks, ${gifts.length} gifts\n`);

    // Pre-process images (resize + compress)
    let imageMap = new Map();
    if (opts.images) {
        console.log(`  🖼  Image directory: ${opts.images}`);
        console.log(`  📐 Resizing to max ${IMAGE_MAX_PX}px, ${IMAGE_QUALITY}% JPEG quality`);
        const allDocs = [...artworks, ...gifts];
        imageMap = await preprocessImages(allDocs, opts.images);
    }

    // Image resolver uses pre-processed cache
    const imageResolver = (doc) => {
        const arn = doc.data?.arn || doc.identifier || '';
        return imageMap.get(arn) || null;
    };

    // Determine output base (strip .pdf if present)
    const outputBase = opts.output.replace(/\.pdf$/i, '');

    // Generate artwork PDF (chunked)
    if (artworks.length > 0) {
        const artworkPath = `${outputBase}_artwork.pdf`;
        await renderChunked(artworks, imageResolver, artworkPath, 'Artwork Catalog');
    }

    // Generate gift PDF (chunked)
    if (gifts.length > 0) {
        const giftPath = `${outputBase}_gift.pdf`;
        await renderChunked(gifts, imageResolver, giftPath, 'Gift Catalog');
    }

    console.log(`\n  ✅ PDF catalog(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Locations Extract
// ══════════════════════════════════════════════════════════════

function escCsv(v) {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function isTargetMatch(arn, cdbDoc, target) {
    if (!target || target === 'all') return true;
    const isGift = cdbDoc ? (cdbDoc.data?.isGift === true) : arn.toUpperCase().startsWith('GRN');
    if (target === 'artwork') return !isGift;
    if (target === 'gift') return isGift;
    return true;
}

function runLocations(opts) {
    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');

    // Filter by target (artwork vs gift)
    const targetFiltered = artifacts.filter(d => isTargetMatch(d.data?.arn || '', d, opts.target));

    // Filter by country (match countryISOCode or coCode)
    const countryFilter = opts.country.toLowerCase();
    const filtered = targetFiltered.filter(d => {
        const loc = d.data?.location;
        const co = d.data?.coCode || '';
        if (!loc) return false;
        return (loc.countryISOCode || '').toLowerCase().includes(countryFilter)
            || co.toLowerCase().includes(countryFilter);
    });

    console.log(`  ✓ Found ${artifacts.length} total artifacts`);
    if (opts.target !== 'all') {
        console.log(`  ✓ ${targetFiltered.length} artifacts match target "${opts.target}"`);
    }
    console.log(`  ✓ ${filtered.length} artifacts match country "${opts.country}"\n`);

    if (filtered.length === 0) {
        console.error('  ❌ No artifacts found for that country.\n');
        process.exit(1);
    }

    // ── 1. Unique buildings ──
    const buildingMap = new Map();
    filtered.forEach(d => {
        const loc = d.data.location;
        const building = loc.building || loc.office || '-';
        if (!buildingMap.has(building)) {
            buildingMap.set(building, {
                building, address: loc.address, postalCode: loc.postalCode,
                city: loc.city, country: loc.countryISOCode, count: 0,
            });
        }
        const entry = buildingMap.get(building);
        entry.count++;
        if (entry.address === '-' && loc.address !== '-') entry.address = loc.address;
        if (entry.postalCode === '-' && loc.postalCode !== '-') entry.postalCode = loc.postalCode;
    });

    const buildingsFile = `${opts.output}_unique_buildings.csv`;
    let csv = 'Building,Address,Postal Code,Country,Artifact Count\n';
    for (const [, b] of [...buildingMap].sort((a, b) => a[0].localeCompare(b[0]))) {
        csv += [b.building, b.address, b.postalCode, b.country, b.count].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(buildingsFile, csv);
    console.log(`  📍 ${buildingsFile}  (${buildingMap.size} unique buildings)`);

    // ── 2. ARN-to-location patch CSV ──
    const patchFile = `${opts.output}_arn_location_patch.csv`;
    let patchCsv = 'ARN,Title,Is Gift,Current Building,Current Floor,Current Room,Current Office,Current Location ID,New Building,New Floor,New Room,New Office\n';
    for (const d of filtered.sort((a, b) => (a.data?.arn || '').localeCompare(b.data?.arn || ''))) {
        const loc = d.data.location || {};
        patchCsv += [
            d.data.arn, d.data.title, d.data.isGift ? 'Yes' : 'No',
            loc.building, loc.floor, loc.room, loc.office, loc.identifier,
            '', '', '', '',
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(patchFile, patchCsv);
    console.log(`  📋 ${patchFile}  (${filtered.length} artifacts)`);

    console.log(`\n  ✅ Location files generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Diff — Masterlist vs CouchDB
// ══════════════════════════════════════════════════════════════

/**
 * Load masterlist Excel into a Map<ARN, record>.
 * Handles the 3-row header in the Audit Copy sheet.
 */
function loadMasterlist(xlsxPath) {
    const xlsx = require('xlsx');
    const wb = xlsx.readFile(xlsxPath);
    const ws = wb.Sheets[wb.SheetNames[0]]; // First sheet
    const raw = xlsx.utils.sheet_to_json(ws, { header: 1 });

    // Find the header row (contains 'ARN')
    let headerIdx = -1;
    for (let i = 0; i < Math.min(10, raw.length); i++) {
        if (raw[i] && raw[i].includes('ARN')) { headerIdx = i; break; }
    }
    if (headerIdx === -1) {
        console.error('  ❌ Could not find header row with "ARN" column in masterlist.\n');
        process.exit(1);
    }

    const headers = raw[headerIdx];
    const map = new Map();

    for (let i = headerIdx + 1; i < raw.length; i++) {
        const row = raw[i];
        if (!row || !row[1]) continue; // col 1 = ARN
        const record = {};
        headers.forEach((h, j) => {
            if (h && row[j] !== undefined && row[j] !== null) {
                record[h] = String(row[j]).replace(/^'/, '').trim(); // strip leading apostrophe
            }
        });
        if (record.ARN) map.set(record.ARN, record);
    }
    return map;
}

/**
 * Build a comparable record from a CouchDB document.
 */
function cdbToComparable(doc) {
    const d = doc.data || {};
    const loc = d.location || {};
    return {
        ARN: d.arn || '',
        Title: d.title || '',
        Artist: d.artist?.name || '',
        Medium: d.medium || '',
        'Entity Code': d.coCode || '',
        Country: loc.countryISOCode || '',
        Entity: d.entity || '',
        Status: d.status || '',
        'Building Name': loc.building || '',
        'Office Name': loc.office || '',
        Floor: String(loc.floor || ''),
        Room: loc.room || '',
        Address: loc.address || '',
        'Postal Code': String(loc.postalCode || ''),
        Category: d.category || '',
    };
}

function runDiffNew(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');
    const cdbMap = new Map();
    artifacts.forEach(d => { if (d.data?.arn) cdbMap.set(d.data.arn, d); });
    console.log(`  ✓ ${cdbMap.size} ARNs in CouchDB\n`);

    // Filter masterMap and cdbMap keys by target
    const masterKeys = [...masterMap.keys()].filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));
    const cdbKeys = [...cdbMap.keys()].filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));

    if (opts.target !== 'all') {
        console.log(`  ✓ ${masterKeys.length} masterlist ARNs match target "${opts.target}"`);
        console.log(`  ✓ ${cdbKeys.length} CouchDB ARNs match target "${opts.target}"\n`);
    }

    const newARNs = masterKeys.filter(a => !cdbMap.has(a)).sort();
    const removedARNs = cdbKeys.filter(a => !masterMap.has(a)).sort();

    // Write new ARNs CSV
    const newFile = `${opts.output}_new_arns.csv`;
    let newCsv = 'ARN,Title,Artist,Entity Code,Country,Entity,Status,Building Name,Office Name,Floor,Room\n';
    for (const arn of newARNs) {
        const r = masterMap.get(arn);
        newCsv += [r.ARN, r.Title, r.Artist, r['Entity Code'], r.Country, r.Entity, r.Status,
            r['Building Name'], r['Office Name'], r.Floor, r.Room].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(newFile, newCsv);
    console.log(`  🆕 ${newFile}  (${newARNs.length} new ARNs)`);

    // Write removed ARNs CSV
    const removedFile = `${opts.output}_removed_arns.csv`;
    let removedCsv = 'ARN,Title,Artist,Entity Code,Status,Building Name\n';
    for (const arn of removedARNs) {
        const c = cdbToComparable(cdbMap.get(arn));
        removedCsv += [c.ARN, c.Title, c.Artist, c['Entity Code'], c.Status, c['Building Name']].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(removedFile, removedCsv);
    console.log(`  🗑️  ${removedFile}  (${removedARNs.length} in CouchDB but not in masterlist)`);

    console.log(`\n  ✅ Diff (new/removed) complete.\n`);
}

function runDiffUpdates(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');
    const cdbMap = new Map();
    artifacts.forEach(d => { if (d.data?.arn) cdbMap.set(d.data.arn, d); });
    console.log(`  ✓ ${cdbMap.size} ARNs in CouchDB\n`);

    const inBoth = [...masterMap.keys()].filter(a => cdbMap.has(a))
        .filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));

    if (opts.target !== 'all') {
        console.log(`  ✓ ${inBoth.length} overlapping ARNs match target "${opts.target}"\n`);
    }

    // Generic subfield noise normalization
    const denoise = v => String(v || '').replace(/^'+/, '')       // remove Excel leading apostrophe
        .replace(/['‘’]/g, '')    // strip curly/straight apostrophes (possessives: "BM's" -> "BMs")
        .replace(/[“”"]/g, '')    // strip double-quote variants
        .replace(/[()]/g, '')              // strip parens
        .trim()
        .toLowerCase()
        .replace(/^0+([1-9]\d*)$/, '$1')                     // strip numeric leading zeros: "01" -> "1"
        .replace(/^(level|lvl|flr|floor|blk|block)\s*/, '')  // strip floor prefix keywords
        .replace(/\s*\/\s*/g, '/')       // normalize spaces around slash: 'A/ B' -> 'A/B'
        .replace(/\s+/g, ' ')             // collapse whitespace
        .replace(/^-$/, '');              // bare dash -> empty

    // Stronger building-name-specific normalization to avoid noise false positives
    const denoiseBuilding = v => {
        let s = String(v || '').replace(/^'+/, '')
            .replace(/['‘’]/g, '')
            .replace(/[“”"]/g, '')
            .replace(/[.,;!]/g, '')        // strip punctuation
            .replace(/[()[\]{}]/g, '')     // strip all bracket types
            .trim()
            .toLowerCase();
        // Expand common abbreviations
        s = s
            .replace(/\bbldg\.?\b/g, 'building')
            .replace(/\bblk\.?\b/g, 'block')
            .replace(/\bst\.?\b/g, 'street')
            .replace(/\brd\.?\b/g, 'road')
            .replace(/\bave\.?\b/g, 'avenue')
            .replace(/\bdr\.?\b/g, 'drive')
            .replace(/\bpl\.?\b/g, 'place')
            .replace(/\bctr\.?\b/g, 'centre')
            .replace(/\bcenter\b/g, 'centre')
            .replace(/\bno\.?\s*/g, '')   // "No. 1" -> "1"
            .replace(/#\s*/g, '')            // "#1" -> "1"
            .replace(/^0+([1-9]\d*)$/, '$1'); // strip numeric leading zeros
        // Normalize separators: slash / dash / & -> single space
        s = s.replace(/[\/\-&]+/g, ' ');
        // Collapse whitespace; bare dash -> empty
        s = s.replace(/\s+/g, ' ').trim().replace(/^-$/, '');
        return s;
    };

    const buildingMoves = [];
    const withinBuildingMoves = [];

    const subfields = ['Office Name', 'Floor', 'Room', 'Address', 'Postal Code'];

    for (const arn of inBoth.sort()) {
        const master = masterMap.get(arn);
        const cdb = cdbToComparable(cdbMap.get(arn));

        const mb = denoiseBuilding(master['Building Name']);
        const cb = denoiseBuilding(cdb['Building Name']);

        // 1. Cross-building move: building names differ even after aggressive denoising
        if (mb !== cb) {
            buildingMoves.push({ arn, master, cdb });
            continue;
        }

        // 2. Within-building move: building matches after denoising, but subfields differ
        const changedSubfields = [];
        for (const f of subfields) {
            const mv = denoise(master[f]);
            const cv = denoise(cdb[f]);
            if (mv !== cv) {
                changedSubfields.push(f);
            }
        }

        if (changedSubfields.length > 0) {
            withinBuildingMoves.push({ arn, master, cdb, changedSubfields });
        }
    }

    // Write Building Moves CSV
    const bMoveFile = `${opts.output}_building_moves.csv`;
    let bCsv = 'ARN,Title,Artist,CouchDB Building,Masterlist Building,CouchDB Office,Masterlist Office,CouchDB Floor,Masterlist Floor,CouchDB Room,Masterlist Room\n';
    for (const { arn, master, cdb } of buildingMoves) {
        bCsv += [
            arn, master.Title, master.Artist,
            cdb['Building Name'], master['Building Name'],
            cdb['Office Name'], master['Office Name'],
            cdb.Floor, master.Floor,
            cdb.Room, master.Room
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(bMoveFile, bCsv);
    console.log(`  🏢 ${bMoveFile}  (${buildingMoves.length} cross-building moves)`);

    // Write Within Building Moves CSV
    const wMoveFile = `${opts.output}_within_building_moves.csv`;
    let wCsv = 'ARN,Title,Artist,Building Name,Changed Fields,CouchDB Office,Masterlist Office,CouchDB Floor,Masterlist Floor,CouchDB Room,Masterlist Room\n';
    for (const { arn, master, cdb, changedSubfields } of withinBuildingMoves) {
        wCsv += [
            arn, master.Title, master.Artist,
            master['Building Name'] || cdb['Building Name'], changedSubfields.join('; '),
            cdb['Office Name'], master['Office Name'],
            cdb.Floor, master.Floor,
            cdb.Room, master.Room
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(wMoveFile, wCsv);
    console.log(`  🚪 ${wMoveFile}  (${withinBuildingMoves.length} within-building moves)`);

    console.log(`\n  ✅ Diff (updates) complete.\n`);
}


// ══════════════════════════════════════════════════════════════
//  Patch — Apply masterlist updates to CouchDB JSON
// ══════════════════════════════════════════════════════════════

function runPatch(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    // Target filter
    const filteredMaster = new Map();
    for (const [arn, rec] of masterMap) {
        const isGiftArn = arn.startsWith('GRN');
        if (opts.target === 'artwork' && isGiftArn) continue;
        if (opts.target === 'gift' && !isGiftArn) continue;
        filteredMaster.set(arn, rec);
    }
    if (opts.target !== 'all') {
        console.log(`  ✓ ${filteredMaster.size} masterlist ARNs match target "${opts.target}"`);
    }

    console.log(`  📂 Loading ${path.basename(opts.input)}...`);
    const raw = fs.readFileSync(opts.input, 'utf8');
    const db = JSON.parse(raw);

    // Index artifact rows by ARN
    const rowIndex = new Map();
    (db.rows || []).forEach((row, idx) => {
        const arn = row?.doc?.data?.arn;
        if (arn) rowIndex.set(arn, idx);
    });
    console.log(`  ✓ ${rowIndex.size} ARNs indexed in CouchDB JSON\n`);

    // ── PHASE 1: Build diff log and apply changes to in-memory db ──
    const LOC_FIELDS = ['building', 'office', 'floor', 'room', 'address', 'postalCode', 'countryISOCode'];
    const ML_KEYS    = ['Building Name', 'Office Name', 'Floor', 'Room', 'Address', 'Postal Code', 'Country'];

    // diffRows: one row per changed field (for UPDATE), one row per location field (for ADD)
    const diffRows = []; // { arn, type, field, oldValue, newValue }
    let updated = 0;
    let added   = 0;

    for (const [arn, rec] of filteredMaster) {
        const mlLocation = {};
        LOC_FIELDS.forEach((lf, i) => { mlLocation[lf] = rec[ML_KEYS[i]] || ''; });

        if (rowIndex.has(arn)) {
            // ── UPDATE: merge masterlist location into existing doc ──
            const doc  = db.rows[rowIndex.get(arn)].doc;
            const oldLoc = doc.data.location || {};
            const newLoc = Object.assign({}, oldLoc, mlLocation);
            doc.data.location = newLoc;

            let anyChange = false;
            for (const lf of LOC_FIELDS) {
                const oldVal = String(oldLoc[lf] || '');
                const newVal = String(newLoc[lf] || '');
                if (oldVal !== newVal) {
                    diffRows.push({ arn, type: 'update', field: lf, oldValue: oldVal, newValue: newVal });
                    anyChange = true;
                }
            }
            if (anyChange) updated++;

        } else {
            // ── ADD: full record from masterlist ──
            const isGift = arn.startsWith('GRN');
            const now    = new Date().toISOString();
            const newDoc = {
                _id:        `io.uob.resources.artifact#${arn}`,
                identifier: `io.uob.resources.artifact#${arn}`,
                data: {
                    arn,
                    title:       rec['Title']       || '',
                    status:      rec['Status']      || '',
                    artMedium:   rec['Medium']      || '',
                    artCategory: rec['Category']    || '',
                    coCode:      rec['Entity Code'] || '',
                    company:     rec['Entity']      || '',
                    isGift,
                    location: mlLocation,
                },
                metadata: {
                    createdDate: now,
                    docType:     'io.uob.resources.artifact',
                    status:      'io.uob.resources.status.available',
                },
            };
            db.rows.push({ doc: newDoc });
            rowIndex.set(arn, db.rows.length - 1);
            added++;
            // Log all location fields for new ARNs
            for (const lf of LOC_FIELDS) {
                diffRows.push({ arn, type: 'add', field: lf, oldValue: '', newValue: mlLocation[lf] });
            }
        }
    }

    const untouched = (rowIndex.size - added) - filteredMaster.size + added; // CouchDB-only count
    const cdbOnlyCount = Array.from(rowIndex.keys()).filter(a => !filteredMaster.has(a)).length;

    // ── PHASE 2: Write pre-patch diff CSV ──
    const diffFile = opts.output.replace(/\.json$/i, '') + '_patch_diff.csv';
    let diffCsv = 'ARN,Type,Field,Old Value,New Value\n';
    for (const r of diffRows) {
        diffCsv += [r.arn, r.type, r.field, r.oldValue, r.newValue].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(diffFile, diffCsv);
    console.log(`  📋 ${diffFile}  (${diffRows.length} field changes across ${updated + added} ARNs)`);

    // ── Print summary ──
    console.log(`\n  📊 Patch summary:`);
    console.log(`     Location updated : ${updated} ARNs`);
    console.log(`     New ARNs added   : ${added} ARNs`);
    console.log(`     Untouched        : ${cdbOnlyCount} ARNs (CouchDB only)`);

    if (opts.dryRun) {
        console.log(`\n  ℹ️  Dry run — diff CSV written, patched JSON NOT written.\n`);
        return;
    }

    // ── PHASE 3: Write patched JSON ──
    const outPath = path.resolve(opts.output);
    fs.writeFileSync(outPath, JSON.stringify(db, null, 2), 'utf8');
    console.log(`\n  💾 ${outPath}`);

    // ── PHASE 4: Verification — re-read patched JSON and check every diff row ──
    console.log(`\n  🔍 Verifying patched JSON against diff CSV...`);
    const patchedRaw = fs.readFileSync(outPath, 'utf8');
    const patchedDb  = JSON.parse(patchedRaw);
    const patchedIdx = new Map();
    (patchedDb.rows || []).forEach(row => {
        const arn = row?.doc?.data?.arn;
        if (arn) patchedIdx.set(arn, row.doc);
    });

    let pass = 0;
    let fail = 0;
    const failures = [];

    for (const r of diffRows) {
        const doc = patchedIdx.get(r.arn);
        if (!doc) {
            fail++;
            failures.push(`  ❌ ARN ${r.arn}: document not found in patched JSON`);
            continue;
        }
        const actual = String(doc.data?.location?.[r.field] || '');
        if (actual === r.newValue) {
            pass++;
        } else {
            fail++;
            failures.push(`  ❌ ${r.arn} [${r.field}]: expected "${r.newValue}", got "${actual}"`);
        }
    }

    if (fail === 0) {
        console.log(`  ✅ Verification PASSED — all ${pass} field changes confirmed correct.`);
    } else {
        console.log(`  ⚠️  Verification: ${pass} passed, ${fail} FAILED`);
        failures.slice(0, 20).forEach(f => console.log(f));
        if (failures.length > 20) console.log(`  ... and ${failures.length - 20} more failures.`);
    }

    console.log(`\n  ✅ Patch complete.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Main
// ══════════════════════════════════════════════════════════════

async function main() {
    const opts = parseArgs(process.argv);

    console.log('\n  ┌──────────────────────────────────────────────┐');
    console.log('  │  Data Extraction CLI                         │');
    console.log('  └──────────────────────────────────────────────┘');

    if (opts.command === 'excel') {
        runExcel(opts);
    } else if (opts.command === 'pdf') {
        await runPdf(opts);
    } else if (opts.command === 'locations') {
        runLocations(opts);
    } else if (opts.command === 'diff') {
        runDiffNew(opts);
        runDiffUpdates(opts);
    } else if (opts.command === 'diff-new') {
        runDiffNew(opts);
    } else if (opts.command === 'diff-updates') {
        runDiffUpdates(opts);
    } else if (opts.command === 'patch') {
        runPatch(opts);
    }

    console.log('  Done! 🎉\n');
}

main().catch(err => {
    console.error('\n  ❌ Error:', err.message || err);
    process.exit(1);
});
