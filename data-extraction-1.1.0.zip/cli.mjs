#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════════
//  Data Extraction CLI
//  Export CouchDB data to Excel workbooks or PDF catalog
//  Requires Node 18+
// ═══════════════════════════════════════════════════════════════

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// ══════════════════════════════════════════════════════════════
//  Help
// ══════════════════════════════════════════════════════════════

function printHelp() {
    console.log(`
  ┌──────────────────────────────────────────────┐
  │  Data Extraction CLI                         │
  │  Export CouchDB data to Excel & PDF          │
  └──────────────────────────────────────────────┘

  Usage:
    node cli.mjs <command> <input> [options]

  Commands:
    excel <file>    Export all entities to separate Excel workbooks
    pdf <file>      Generate artwork catalog PDF (one page per artwork)
    help            Show this help message

  Arguments:
    <file>          Path to couchdb.json or couchdb.txt

  Options (excel):
    -o, --output <prefix>   Output filename prefix (default: "export")

  Options (pdf):
    -o, --output <path>     Output PDF filename (default: "artwork_catalog.pdf")
    --images <dir>          Local image directory mirroring S3 paths
                            Images are resolved as: <dir>/<s3_path>
                            e.g. --images ./assets will look for
                            ./assets/protected/common/artifact/SG/xxx.jpg

  Examples:
    node cli.mjs help
    node cli.mjs excel ./couchdb.json
    node cli.mjs excel ./couchdb.json -o mydata
    node cli.mjs pdf ./couchdb.json
    node cli.mjs pdf ./couchdb.json -o report.pdf --images ./s3_mirror
`);
}

// ══════════════════════════════════════════════════════════════
//  Argument Parsing
// ══════════════════════════════════════════════════════════════

function parseArgs(argv) {
    const args = argv.slice(2);

    if (args.length === 0 || args[0] === 'help' || args.includes('-h') || args.includes('--help')) {
        printHelp();
        process.exit(0);
    }

    const command = args[0];
    if (!['excel', 'pdf'].includes(command)) {
        console.error(`\n  ❌ Unknown command "${command}". Use "excel", "pdf", or "help".\n`);
        process.exit(1);
    }

    const input = args[1];
    if (!input) {
        console.error(`\n  ❌ Missing input file. Usage: node cli.mjs ${command} <couchdb.json>\n`);
        process.exit(1);
    }

    const resolvedInput = path.resolve(input);
    if (!fs.existsSync(resolvedInput)) {
        console.error(`\n  ❌ File not found: ${resolvedInput}\n`);
        process.exit(1);
    }

    const parsed = { command, input: resolvedInput, output: null, images: null };

    // Defaults
    if (command === 'excel') parsed.output = 'export';
    if (command === 'pdf') parsed.output = 'artwork_catalog.pdf';

    // Parse remaining options
    for (let i = 2; i < args.length; i++) {
        switch (args[i]) {
            case '-o':
            case '--output':
                parsed.output = args[++i];
                break;
            case '--images':
                parsed.images = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.images)) {
                    console.error(`\n  ❌ Images directory not found: ${parsed.images}\n`);
                    process.exit(1);
                }
                break;
            default:
                console.error(`\n  ❌ Unknown option "${args[i]}". Run "node cli.mjs help" for usage.\n`);
                process.exit(1);
        }
    }

    return parsed;
}

// ══════════════════════════════════════════════════════════════
//  Flatten Helpers
// ══════════════════════════════════════════════════════════════

function camelToTitle(str) {
    if (!str) return '';
    let res = str.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
    res = res.replace(/Id$/i, 'ID');
    res = res.replace(/^Arn$/i, 'ARN');
    return res;
}

function getColumnName(parentPath, key) {
    let cleanKey = camelToTitle(key);
    if (!parentPath) return cleanKey;
    if (parentPath === 'data') return cleanKey;
    if (parentPath.startsWith('data_')) {
        let cleanPath = parentPath.substring(5).split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    if (parentPath.startsWith('metadata')) {
        let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
    return `${cleanPath} ${cleanKey}`;
}

function flattenObject(ob, parentPath = '') {
    const toReturn = {};
    for (const i in ob) {
        if (!ob.hasOwnProperty(i)) continue;
        let newPath = parentPath ? parentPath + '_' + i : i;
        if ((typeof ob[i]) === 'object' && ob[i] !== null) {
            if (Array.isArray(ob[i])) {
                let str = JSON.stringify(ob[i]);
                if (str.length > 32000) str = str.substring(0, 32000) + '... [TRUNCATED]';
                toReturn[getColumnName(parentPath, i)] = str;
            } else {
                const flatObject = flattenObject(ob[i], newPath);
                for (const x in flatObject) {
                    if (!flatObject.hasOwnProperty(x)) continue;
                    toReturn[x] = flatObject[x];
                }
            }
        } else {
            let val = ob[i];
            if (typeof val === 'string' && val.length > 32000) {
                val = val.substring(0, 32000) + '... [TRUNCATED]';
            }
            toReturn[getColumnName(parentPath, i)] = val;
        }
    }
    return toReturn;
}

// ══════════════════════════════════════════════════════════════
//  Data Loading
// ══════════════════════════════════════════════════════════════

function loadDocuments(inputFilePath) {
    console.log(`\n  📂 Loading ${inputFilePath}...`);
    const rawData = fs.readFileSync(inputFilePath, 'utf8');
    const data = JSON.parse(rawData);
    return data.rows.filter(r => r.doc).map(r => r.doc);
}

function categorizeDocuments(docs) {
    const collections = {};      // for Excel (flattened)
    const rawCollections = {};   // for PDF (raw docs)

    for (const doc of docs) {
        let docType = null;
        if (doc.metadata && doc.metadata.docType) docType = doc.metadata.docType;
        else if (doc.docType) docType = doc.docType;
        else if (doc.type) docType = doc.type;
        if (!docType || docType.startsWith('_design/')) continue;

        let isGift = doc.data && doc.data.isGift === true;

        // Clone for flattening (we strip internal fields)
        const docCopy = JSON.parse(JSON.stringify(doc));
        delete docCopy._id;
        delete docCopy._rev;
        delete docCopy['~version'];
        delete docCopy._attachments;
        delete docCopy._conflicts;

        const flattenedDoc = flattenObject(docCopy);

        let sheetName = docType.replace('io.uob.resources.', '');
        if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

        let collectionName = sheetName;
        if (sheetName === 'artifact') {
            collectionName = isGift ? 'gift' : 'artwork';
        }

        if (!collections[collectionName]) collections[collectionName] = [];
        collections[collectionName].push(flattenedDoc);

        if (!rawCollections[collectionName]) rawCollections[collectionName] = [];
        rawCollections[collectionName].push(doc);
    }

    return { collections, rawCollections };
}

// ══════════════════════════════════════════════════════════════
//  Excel Export
// ══════════════════════════════════════════════════════════════

function runExcel(opts) {
    const docs = loadDocuments(opts.input);
    const { collections } = categorizeDocuments(docs);

    console.log(`  ✓ Found ${Object.keys(collections).length} collections\n`);

    const xlsx = require('xlsx');
    let count = 0;

    for (const [name, records] of Object.entries(collections)) {
        const fileName = `${opts.output}_${name}.xlsx`;
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(records);
        let safeSheet = name.length > 31 ? name.substring(0, 31) : name;
        xlsx.utils.book_append_sheet(wb, ws, safeSheet);
        xlsx.writeFile(wb, fileName);
        console.log(`  📊 ${fileName}  (${records.length} records)`);
        count++;
    }

    console.log(`\n  ✅ ${count} Excel file(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  PDF Export — Artwork Catalog
// ══════════════════════════════════════════════════════════════

async function runPdf(opts) {
    const { renderToFile } = await import('@react-pdf/renderer');
    const { createArtworkCatalog } = await import('./pdf/ArtworkCatalog.mjs');

    const docs = loadDocuments(opts.input);
    const { rawCollections } = categorizeDocuments(docs);

    const artworks = rawCollections.artwork || [];
    const gifts = rawCollections.gift || [];

    if (artworks.length === 0 && gifts.length === 0) {
        console.error('\n  ❌ No artwork or gift records found in the input file.\n');
        process.exit(1);
    }

    console.log(`  ✓ Found ${artworks.length} artworks, ${gifts.length} gifts\n`);

    // Image resolver
    let imageResolver = null;
    let imagesFound = 0;

    if (opts.images) {
        console.log(`  🖼  Image directory: ${opts.images}`);
        imageResolver = (doc) => {
            const images = doc.data && doc.data.images;
            if (!images || images.length === 0) return null;
            const imgUrl = images[0].url;
            // Try literal path first (URL-encoded folder names)
            const localPath = path.join(opts.images, imgUrl);
            if (fs.existsSync(localPath)) {
                imagesFound++;
                return localPath;
            }
            // Fallback: try URL-decoded path (e.g. %20 → space)
            try {
                const decodedUrl = decodeURIComponent(imgUrl);
                if (decodedUrl !== imgUrl) {
                    const decodedPath = path.join(opts.images, decodedUrl);
                    if (fs.existsSync(decodedPath)) {
                        imagesFound++;
                        return decodedPath;
                    }
                }
            } catch { /* ignore decode errors */ }
            return null;
        };
    }

    // Determine output base (strip .pdf if present)
    const outputBase = opts.output.replace(/\.pdf$/i, '');

    // Generate artwork PDF
    if (artworks.length > 0) {
        const artworkPath = `${outputBase}_artwork.pdf`;
        console.log(`  ⏳ Rendering ${artworks.length} artwork pages to ${artworkPath}...`);
        const artworkCatalog = createArtworkCatalog(artworks, imageResolver, 'Artwork Catalog');
        await renderToFile(artworkCatalog, artworkPath);
        console.log(`  ✓ ${artworkPath}`);
    }

    // Generate gift PDF
    if (gifts.length > 0) {
        const giftPath = `${outputBase}_gift.pdf`;
        console.log(`  ⏳ Rendering ${gifts.length} gift pages to ${giftPath}...`);
        const giftCatalog = createArtworkCatalog(gifts, imageResolver, 'Gift Catalog');
        await renderToFile(giftCatalog, giftPath);
        console.log(`  ✓ ${giftPath}`);
    }

    if (opts.images) {
        console.log(`  🖼  ${imagesFound} items had local images`);
    }

    console.log(`\n  ✅ PDF catalog(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Main
// ══════════════════════════════════════════════════════════════

async function main() {
    const opts = parseArgs(process.argv);

    console.log('\n  ┌──────────────────────────────────────────────┐');
    console.log('  │  Data Extraction CLI                         │');
    console.log('  └──────────────────────────────────────────────┘');

    if (opts.command === 'excel') {
        runExcel(opts);
    } else if (opts.command === 'pdf') {
        await runPdf(opts);
    }

    console.log('  Done! 🎉\n');
}

main().catch(err => {
    console.error('\n  ❌ Error:', err.message || err);
    process.exit(1);
});
