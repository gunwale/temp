#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════════
//  Data Extraction CLI
//  Export CouchDB data to Excel workbooks or PDF catalog
//  Requires Node 18+
// ═══════════════════════════════════════════════════════════════

// ── Auto-configure memory limits ──────────────────────────────
// Re-spawn with 6 GB heap + GC access if not already set
const MAX_HEAP_MB = 6144;
if (!process.env.__CLI_MEM_SET) {
    const { execFileSync } = await import('child_process');
    try {
        execFileSync(process.execPath, [
            `--max-old-space-size=${MAX_HEAP_MB}`,
            '--expose-gc',
            ...process.argv.slice(1),
        ], {
            stdio: 'inherit',
            env: { ...process.env, __CLI_MEM_SET: '1' },
        });
    } catch (e) {
        process.exit(e.status || 1);
    }
    process.exit(0);
}

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// ══════════════════════════════════════════════════════════════
//  Help
// ══════════════════════════════════════════════════════════════

function printHelp() {
    console.log(`
  ┌──────────────────────────────────────────────┐
  │  Data Extraction CLI                         │
  │  Export CouchDB data to Excel & PDF          │
  └──────────────────────────────────────────────┘

  Usage:
    node cli.mjs <command> <input> [options]

  Commands:
    excel <file>          Export all entities to separate Excel workbooks
    pdf <file>            Generate artwork catalog PDF (one page per artwork)
    locations <file>      Extract unique buildings & ARN location patch CSV
    diff <file>           Run both diff-new and diff-updates
    diff-new <file>       Find new/removed ARNs (masterlist vs CouchDB)
    diff-updates <file>   Find updated fields for existing ARNs
    patch <file>          Apply masterlist updates into CouchDB JSON (add/update, no remove)
    patch-import <file>   Import & merge from a custom-column Excel (matched by ARN)
    patch-images <file>   Register local image files into CouchDB JSON (matched by ARN prefix)
    match-images <file>   Match image filenames to artwork titles and update image paths
    help                  Show this help message

  Arguments:
    <file>          Path to couchdb.json or couchdb.txt

  Options (excel):
    -o, --output <prefix>   Output filename prefix (default: "export")

  Options (pdf):
    -o, --output <path>     Output PDF filename (default: "artwork_catalog.pdf")
    --images <dir>          Local image directory mirroring S3 paths
                            Images are resolved as: <dir>/<s3_path>
                            e.g. --images ./assets will look for
                            ./assets/protected/common/artifact/SG/xxx.jpg

  Options (locations):
    -o, --output <prefix>   Output filename prefix (default: "sg")
    --country <name>        Filter by country (default: "Singapore")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")

  Options (diff, diff-new, diff-updates):
    --masterlist <xlsx>     Path to the masterlist Excel file (required)
    -o, --output <prefix>   Output filename prefix (default: "diff")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")

  Output files (diff-updates):
    <prefix>_building_moves.csv
        Cross-building moves: ARNs where the building name differs between
        CouchDB and the masterlist after noise normalization.
        Columns: ARN, Title, Artist, CouchDB Building, Masterlist Building,
                 CouchDB Office, Masterlist Office,
                 CouchDB Floor, Masterlist Floor, CouchDB Room, Masterlist Room

    <prefix>_within_building_moves.csv
        Within-building moves: ARNs in the same building where sub-location
        fields (Office, Floor, Room, Address, Postal Code) differ.
        Columns: ARN, Title, Artist, Building Name, Changed Fields,
                 CouchDB Office, Masterlist Office,
                 CouchDB Floor, Masterlist Floor, CouchDB Room, Masterlist Room

  Denoise rules applied to all location comparisons:
    - Leading Excel apostrophes and curly/straight quotes stripped
    - Numeric leading zeros stripped: "01" -> "1"
    - Floor prefix keywords stripped: "Level 3" -> "3"
    - Spaces around slashes normalised: "A/ B" -> "A/B"
    - Building names: abbreviations expanded (Bldg, Blk, Ctr, St, Rd, etc.),
      slashes/dashes/ampersands treated as spaces

  Options (patch):
    --masterlist <xlsx>     Path to the masterlist Excel file (required)
    -o, --output <path>     Output JSON filename (default: "patched_couchdb.json")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")
    --dry-run               Print summary only, do not write output file

  Output file (patch):
    <output>.json
        A copy of the CouchDB JSON with masterlist location data merged in.
        Rules:
          • Existing ARNs — location object overwritten with masterlist values
            (building, office, floor, room, address, postalCode, countryISOCode).
            All other CouchDB fields are left untouched.
          • New ARNs (in masterlist only) — full record added including all
            masterlist fields (title, status, medium, category, entity, location).
          • CouchDB-only ARNs — never removed.

  Examples:
    node cli.mjs help
    node cli.mjs excel ./couchdb.json
    node cli.mjs pdf ./couchdb.json -o report.pdf --images ./s3_mirror
    node cli.mjs locations ./couchdb.json --target artwork
    node cli.mjs locations ./couchdb.json --country Thailand -o th
    node cli.mjs diff ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork
    node cli.mjs diff-new ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork
    node cli.mjs diff-updates ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork -o sg_artwork
    node cli.mjs diff-updates ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target gift -o sg_gift
    node cli.mjs patch ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork -o patched.json
    node cli.mjs patch ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --dry-run
    node cli.mjs patch-import ./couchdb.json --excel data.xlsx -o imported.json
    node cli.mjs patch-import ./couchdb.json --excel data.xlsx --dry-run
    node cli.mjs patch-images ./couchdb.json --images ./photos -o updated.json
    node cli.mjs patch-images ./couchdb.json --images ./photos --dry-run
    node cli.mjs match-images ./couchdb.json --images ./photos -o matched.json
    node cli.mjs match-images ./couchdb.json --images ./photos --dry-run

  Options (patch-images):
    --images <dir>          Directory containing image files (required)
    -o, --output <path>     Output JSON filename (default: "images_couchdb.json")
    --dry-run               Generate diff CSV only, do not write output JSON

  Image file naming convention:
    Files must start with the ARN followed by underscore or dot:
      UOB00000001_front.jpg   → matched to ARN UOB00000001
      UOB00000001_back.jpg    → matched to ARN UOB00000001
      UOB00000001.jpg         → matched to ARN UOB00000001
    Supported formats: .jpg  .jpeg  .png  .gif  .webp  .tiff  .bmp

  Output file (patch-images):
    <output>.json
        CouchDB JSON with images[] and thumbnail updated for each matched ARN.
        Rules: images sorted alphabetically; first image becomes thumbnail;
               existing images array is replaced; unmatched ARNs untouched.
    <output>_images_diff.csv
        ARN, Action, Image Count, Filenames, Thumbnail

  Options (patch-import):
    --excel <xlsx>          Path to the import Excel file (required)
    -o, --output <path>     Output JSON filename (default: "imported_couchdb.json")
    --dry-run               Generate diff CSV only, do not write output JSON
    --sheet <name|index>    Sheet name or 0-based index to read (default: first sheet)
    --header-row <n>        1-based row number containing column headers (default: 1)
    --col-offset <n>        Shift all column indices by N (default: 0).
                            Use 1 if the sheet has a leading comment column before ARN.

  Output file (patch-import):
    <output>.json
        CouchDB JSON with Excel data merged in, matched by ARN (col 0).
        Rules: existing ARNs — all mapped fields updated; new ARNs — full
               record added; CouchDB-only ARNs — never removed.

  Column index mapping (0-based, matched by position not header name):
     0  ARN                   16  w/o frame height (artHeight)
     1  title                 17  w/o frame width  (artWidth)
     2  artist name           18  w/o frame depth  (artDepth)
     3  medium                19  w frame height   (artFrameHeight)
     4  entity code           20  w frame width    (artFrameWidth)
     5  country               21  w frame depth    (artFrameDepth)
     6  entity                22  orientation
     7  status                23  category
     8  state                 24  internal
     9  city                  25  min value
    10  postal code           26  max value
    11  address               27  value date
    12  building              28  value by
    13  office name           29  valuation notes
    14  floor                 30  artwork condition
    15  room                  31  artwork condition comments
                              32  frame condition
                              33  mount condition
                              34  tags
                              35  year
                              36  acquisition date
                              37  artwork writeup
                              38  award

  Options (match-images):
    --images <dir>          Directory containing image files (required)
    -o, --output <path>     Output JSON filename (default: "matched_couchdb.json")
    --dry-run               Write match report CSV only, do not update JSON

  How matching works (match-images):
    Both the image filename (without extension) and the artwork title are
    sanitized before comparison:
      • Lowercase
      • ALL non-alphanumeric characters replaced with spaces
      • Consecutive spaces collapsed

    A 100% Match requires ALL 3 of these conditions to be met:
    1. Title Match: The filename (after stripping the prefix) exactly matches the CouchDB title.
    2. Year Match: The image folder name contains the CouchDB artwork year.
    3. Country Match: The image folder name contains the CouchDB artwork country.

    If a file matches exactly one ARN across all 3 conditions, the JSON is updated.
    If it matches multiple ARNs or zero ARNs, it is marked with 0 confidence
    in the CSV for manual review, and the JSON is NOT updated.

  Output files (match-images):
    <output>.json
        CouchDB JSON with images[] and thumbnail updated for 100%-matched ARNs.
    <output>_match_report.csv
        Filename, ARN, Matched Title, Confidence (%), Action
        Rows for every image file: matched/unmatched/ambiguous.
`);
}

// ══════════════════════════════════════════════════════════════
//  Argument Parsing
// ══════════════════════════════════════════════════════════════

function parseArgs(argv) {
    const args = argv.slice(2);

    if (args.length === 0 || args[0] === 'help' || args.includes('-h') || args.includes('--help')) {
        printHelp();
        process.exit(0);
    }

    const command = args[0];
    if (!['excel', 'pdf', 'locations', 'diff', 'diff-new', 'diff-updates', 'patch', 'patch-import', 'patch-images', 'match-images'].includes(command)) {
        console.error(`\n  ❌ Unknown command "${command}". Use "excel", "pdf", "locations", "diff", "diff-new", "diff-updates", "patch", "patch-import", "patch-images", "match-images", or "help".\n`);
        process.exit(1);
    }

    const input = args[1];
    if (!input) {
        console.error(`\n  ❌ Missing input file. Usage: node cli.mjs ${command} <couchdb.json>\n`);
        process.exit(1);
    }

    const resolvedInput = path.resolve(input);
    if (!fs.existsSync(resolvedInput)) {
        console.error(`\n  ❌ File not found: ${resolvedInput}\n`);
        process.exit(1);
    }

    const parsed = { command, input: resolvedInput, output: null, images: null, country: 'Singapore', masterlist: null, target: 'all', dryRun: false, excel: null, sheet: 0, headerRow: 1, colOffset: 0 };

    // Defaults
    if (command === 'excel') parsed.output = 'export';
    if (command === 'pdf') parsed.output = 'artwork_catalog.pdf';
    if (command === 'locations') parsed.output = 'sg';
    if (command === 'diff' || command === 'diff-new' || command === 'diff-updates') parsed.output = 'diff';
    if (command === 'patch') parsed.output = 'patched_couchdb.json';
    if (command === 'patch-import') parsed.output = 'imported_couchdb.json';
    if (command === 'patch-images') parsed.output = 'images_couchdb.json';
    if (command === 'match-images') parsed.output = 'matched_couchdb.json';

    // Parse remaining options
    for (let i = 2; i < args.length; i++) {
        switch (args[i]) {
            case '-o':
            case '--output':
                parsed.output = args[++i];
                break;
            case '--images':
                parsed.images = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.images)) {
                    console.error(`\n  ❌ Images directory not found: ${parsed.images}\n`);
                    process.exit(1);
                }
                break;
            case '--country':
                parsed.country = args[++i];
                break;
            case '--masterlist':
                parsed.masterlist = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.masterlist)) {
                    console.error(`\n  ❌ Masterlist file not found: ${parsed.masterlist}\n`);
                    process.exit(1);
                }
                break;
            case '--dry-run':
                parsed.dryRun = true;
                break;
            case '--excel':
                parsed.excel = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.excel)) {
                    console.error(`\n  ❌ Excel file not found: ${parsed.excel}\n`);
                    process.exit(1);
                }
                break;
            case '--sheet': {
                const sv = args[++i];
                parsed.sheet = isNaN(sv) ? sv : Number(sv);
                break;
            }
            case '--header-row':
                parsed.headerRow = parseInt(args[++i], 10);
                break;
            case '--col-offset':
                parsed.colOffset = parseInt(args[++i], 10);
                break;
            case '--target':
                parsed.target = args[++i]?.toLowerCase();
                if (!['artwork', 'gift', 'all'].includes(parsed.target)) {
                    console.error(`\n  ❌ Invalid target "${parsed.target}". Use "artwork", "gift", or "all".\n`);
                    process.exit(1);
                }
                break;
            default:
                console.error(`\n  ❌ Unknown option "${args[i]}". Run "node cli.mjs help" for usage.\n`);
                process.exit(1);
        }
    }

    return parsed;
}

// ══════════════════════════════════════════════════════════════
//  Flatten Helpers
// ══════════════════════════════════════════════════════════════

function camelToTitle(str) {
    if (!str) return '';
    let res = str.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
    res = res.replace(/Id$/i, 'ID');
    res = res.replace(/^Arn$/i, 'ARN');
    return res;
}

function getColumnName(parentPath, key) {
    let cleanKey = camelToTitle(key);
    if (!parentPath) return cleanKey;
    if (parentPath === 'data') return cleanKey;
    if (parentPath.startsWith('data_')) {
        let cleanPath = parentPath.substring(5).split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    if (parentPath.startsWith('metadata')) {
        let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
    return `${cleanPath} ${cleanKey}`;
}

function flattenObject(ob, parentPath = '') {
    const toReturn = {};
    for (const i in ob) {
        if (!ob.hasOwnProperty(i)) continue;
        let newPath = parentPath ? parentPath + '_' + i : i;
        if ((typeof ob[i]) === 'object' && ob[i] !== null) {
            if (Array.isArray(ob[i])) {
                let str = JSON.stringify(ob[i]);
                if (str.length > 32000) str = str.substring(0, 32000) + '... [TRUNCATED]';
                toReturn[getColumnName(parentPath, i)] = str;
            } else {
                const flatObject = flattenObject(ob[i], newPath);
                for (const x in flatObject) {
                    if (!flatObject.hasOwnProperty(x)) continue;
                    toReturn[x] = flatObject[x];
                }
            }
        } else {
            let val = ob[i];
            if (typeof val === 'string' && val.length > 32000) {
                val = val.substring(0, 32000) + '... [TRUNCATED]';
            }
            toReturn[getColumnName(parentPath, i)] = val;
        }
    }
    return toReturn;
}

// ══════════════════════════════════════════════════════════════
//  Data Loading
// ══════════════════════════════════════════════════════════════

function loadDocuments(inputFilePath) {
    console.log(`\n  📂 Loading ${inputFilePath}...`);
    const rawData = fs.readFileSync(inputFilePath, 'utf8');
    const data = JSON.parse(rawData);
    return data.rows.filter(r => r.doc).map(r => r.doc);
}

function categorizeDocuments(docs) {
    const collections = {};      // for Excel (flattened)
    const rawCollections = {};   // for PDF (raw docs)

    for (const doc of docs) {
        let docType = null;
        if (doc.metadata && doc.metadata.docType) docType = doc.metadata.docType;
        else if (doc.docType) docType = doc.docType;
        else if (doc.type) docType = doc.type;
        if (!docType || docType.startsWith('_design/')) continue;

        let isGift = doc.data && doc.data.isGift === true;

        // Clone for flattening (we strip internal fields)
        const docCopy = JSON.parse(JSON.stringify(doc));
        delete docCopy._id;
        delete docCopy._rev;
        delete docCopy['~version'];
        delete docCopy._attachments;
        delete docCopy._conflicts;

        const flattenedDoc = flattenObject(docCopy);

        let sheetName = docType.replace('io.uob.resources.', '');
        if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

        let collectionName = sheetName;
        if (sheetName === 'artifact') {
            collectionName = isGift ? 'gift' : 'artwork';
        }

        if (!collections[collectionName]) collections[collectionName] = [];
        collections[collectionName].push(flattenedDoc);

        if (!rawCollections[collectionName]) rawCollections[collectionName] = [];
        rawCollections[collectionName].push(doc);
    }

    return { collections, rawCollections };
}

// ══════════════════════════════════════════════════════════════
//  Excel Export
// ══════════════════════════════════════════════════════════════

function runExcel(opts) {
    const docs = loadDocuments(opts.input);
    const { collections } = categorizeDocuments(docs);

    console.log(`  ✓ Found ${Object.keys(collections).length} collections\n`);

    const xlsx = require('xlsx');
    let count = 0;

    for (const [name, records] of Object.entries(collections)) {
        const fileName = `${opts.output}_${name}.xlsx`;
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(records);
        let safeSheet = name.length > 31 ? name.substring(0, 31) : name;
        xlsx.utils.book_append_sheet(wb, ws, safeSheet);
        xlsx.writeFile(wb, fileName);
        console.log(`  📊 ${fileName}  (${records.length} records)`);
        count++;
    }

    console.log(`\n  ✅ ${count} Excel file(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  PDF Export — Artwork Catalog
// ══════════════════════════════════════════════════════════════

const IMAGE_MAX_PX = 800;    // max dimension (width or height)
const IMAGE_QUALITY = 75;    // JPEG quality (1-100)
const CACHE_DIR = path.join(__dirname, '.image_cache');

/**
 * Resolve the original image path for a document.
 * Tries URL-encoded path first, then decoded fallback.
 */
function resolveOriginalImage(imagesDir, doc) {
    const images = doc.data && doc.data.images;
    if (!images || images.length === 0) return null;
    const imgUrl = images[0].url;

    // Try literal path (URL-encoded folder names)
    const localPath = path.join(imagesDir, imgUrl);
    if (fs.existsSync(localPath)) return localPath;

    // Fallback: URL-decoded path (e.g. %20 → space)
    try {
        const decodedUrl = decodeURIComponent(imgUrl);
        if (decodedUrl !== imgUrl) {
            const decodedPath = path.join(imagesDir, decodedUrl);
            if (fs.existsSync(decodedPath)) return decodedPath;
        }
    } catch { /* ignore decode errors */ }
    return null;
}

/**
 * Pre-process images: resize + compress into .image_cache/
 * Returns a Map<docArn, cachedPath>
 */
async function preprocessImages(docs, imagesDir) {
    const sharp = (await import('sharp')).default;

    if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });

    const imageMap = new Map();
    let processed = 0;
    let skipped = 0;
    const missingList = [];

    for (const doc of docs) {
        const arn = doc.data?.arn || doc.identifier || '';
        const originalPath = resolveOriginalImage(imagesDir, doc);
        if (!originalPath) {
            // Record expected path for debugging
            const imgUrl = doc.data?.images?.[0]?.url;
            const expectedPath = imgUrl ? path.join(imagesDir, imgUrl) : null;
            missingList.push({ arn, expectedPath });
            continue;
        }

        // Cache key: use a safe filename from the original
        const ext = path.extname(originalPath).toLowerCase();
        const baseName = path.basename(originalPath, ext);
        const cachedPath = path.join(CACHE_DIR, `${baseName}_thumb.jpg`);

        // Skip if already cached
        if (fs.existsSync(cachedPath)) {
            imageMap.set(arn, cachedPath);
            skipped++;
            continue;
        }

        try {
            await sharp(originalPath)
                .resize(IMAGE_MAX_PX, IMAGE_MAX_PX, { fit: 'inside', withoutEnlargement: true })
                .jpeg({ quality: IMAGE_QUALITY, mozjpeg: true })
                .toFile(cachedPath);
            imageMap.set(arn, cachedPath);
            processed++;
        } catch (err) {
            console.error(`  ⚠  Failed to process ${path.basename(originalPath)}: ${err.message}`);
        }
    }

    console.log(`  🖼  Images: ${processed} resized, ${skipped} cached, ${missingList.length} not found`);

    // Show first 5 missing paths as examples
    if (missingList.length > 0) {
        const show = missingList.slice(0, 5);
        show.forEach(m => {
            console.log(`     ✗ ${m.arn} → ${m.expectedPath || '(no image URL)'}`);
        });
        if (missingList.length > 5) {
            console.log(`     ... and ${missingList.length - 5} more`);
        }
        // Write full list to log file
        const logPath = path.join(__dirname, 'missing_images.log');
        const logLines = missingList.map(m => `${m.arn}\t${m.expectedPath || 'N/A'}`).join('\n');
        fs.writeFileSync(logPath, logLines + '\n');
        console.log(`  📝 Full list saved to missing_images.log`);
    }

    return imageMap;
}

const CHUNK_SIZE = 100;  // pages per rendering batch (lower = less RAM)

/**
 * Render a collection in chunks and merge into a single PDF.
 * This keeps peak memory proportional to CHUNK_SIZE instead of total pages.
 */
async function renderChunked(docs, imageResolver, outputPath, catalogTitle) {
    const { renderToFile } = await import('@react-pdf/renderer');
    const { createArtworkCatalog } = await import('./pdf/ArtworkCatalog.mjs');
    const { PDFDocument } = await import('pdf-lib');

    const totalPages = docs.length;
    const totalChunks = Math.ceil(totalPages / CHUNK_SIZE);

    // If small enough, render directly (no chunking overhead)
    if (totalPages <= CHUNK_SIZE) {
        console.log(`  ⏳ Rendering ${totalPages} pages to ${outputPath}...`);
        const catalog = createArtworkCatalog(docs, imageResolver, catalogTitle);
        await renderToFile(catalog, outputPath);
        console.log(`  ✓ ${outputPath}`);
        return;
    }

    console.log(`  ⏳ Rendering ${totalPages} pages in ${totalChunks} chunks (${CHUNK_SIZE}/chunk) to ${outputPath}...`);

    const tempDir = path.join(__dirname, '.pdf_temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const tempFiles = [];

    for (let i = 0; i < totalChunks; i++) {
        const start = i * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, totalPages);
        const chunk = docs.slice(start, end);
        const tempFile = path.join(tempDir, `chunk_${i}.pdf`);

        const heapMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(0);
        console.log(`     chunk ${i + 1}/${totalChunks} (pages ${start + 1}–${end}) [heap: ${heapMB} MB]`);
        const catalog = createArtworkCatalog(chunk, imageResolver, catalogTitle);
        await renderToFile(catalog, tempFile);
        tempFiles.push(tempFile);

        // Force GC between chunks to free memory
        if (global.gc) global.gc();
    }

    // Merge all chunks with pdf-lib
    console.log(`  📎 Merging ${totalChunks} chunks...`);
    const mergedPdf = await PDFDocument.create();

    for (const tempFile of tempFiles) {
        const chunkBytes = fs.readFileSync(tempFile);
        const chunkPdf = await PDFDocument.load(chunkBytes);
        const pages = await mergedPdf.copyPages(chunkPdf, chunkPdf.getPageIndices());
        pages.forEach(page => mergedPdf.addPage(page));
    }

    const mergedBytes = await mergedPdf.save();
    fs.writeFileSync(outputPath, mergedBytes);

    // Cleanup temp files
    for (const f of tempFiles) fs.unlinkSync(f);
    fs.rmSync(tempDir, { recursive: true });

    console.log(`  ✓ ${outputPath} (${totalPages} pages)`);
}

async function runPdf(opts) {
    let docs = loadDocuments(opts.input);
    const { rawCollections } = categorizeDocuments(docs);

    // Free raw docs array to reclaim ~130 MB
    docs = null;
    if (global.gc) global.gc();

    const artworks = rawCollections.artwork || [];
    const gifts = rawCollections.gift || [];

    if (artworks.length === 0 && gifts.length === 0) {
        console.error('\n  ❌ No artwork or gift records found in the input file.\n');
        process.exit(1);
    }

    console.log(`  ✓ Found ${artworks.length} artworks, ${gifts.length} gifts\n`);

    // Pre-process images (resize + compress)
    let imageMap = new Map();
    if (opts.images) {
        console.log(`  🖼  Image directory: ${opts.images}`);
        console.log(`  📐 Resizing to max ${IMAGE_MAX_PX}px, ${IMAGE_QUALITY}% JPEG quality`);
        const allDocs = [...artworks, ...gifts];
        imageMap = await preprocessImages(allDocs, opts.images);
    }

    // Image resolver uses pre-processed cache
    const imageResolver = (doc) => {
        const arn = doc.data?.arn || doc.identifier || '';
        return imageMap.get(arn) || null;
    };

    // Determine output base (strip .pdf if present)
    const outputBase = opts.output.replace(/\.pdf$/i, '');

    // Generate artwork PDF (chunked)
    if (artworks.length > 0) {
        const artworkPath = `${outputBase}_artwork.pdf`;
        await renderChunked(artworks, imageResolver, artworkPath, 'Artwork Catalog');
    }

    // Generate gift PDF (chunked)
    if (gifts.length > 0) {
        const giftPath = `${outputBase}_gift.pdf`;
        await renderChunked(gifts, imageResolver, giftPath, 'Gift Catalog');
    }

    console.log(`\n  ✅ PDF catalog(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Locations Extract
// ══════════════════════════════════════════════════════════════

function escCsv(v) {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function isTargetMatch(arn, cdbDoc, target) {
    if (!target || target === 'all') return true;
    const isGift = cdbDoc ? (cdbDoc.data?.isGift === true) : arn.toUpperCase().startsWith('GRN');
    if (target === 'artwork') return !isGift;
    if (target === 'gift') return isGift;
    return true;
}

function runLocations(opts) {
    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');

    // Filter by target (artwork vs gift)
    const targetFiltered = artifacts.filter(d => isTargetMatch(d.data?.arn || '', d, opts.target));

    // Filter by country (match countryISOCode or coCode)
    const countryFilter = opts.country.toLowerCase();
    const filtered = targetFiltered.filter(d => {
        const loc = d.data?.location;
        const co = d.data?.coCode || '';
        if (!loc) return false;
        return (loc.countryISOCode || '').toLowerCase().includes(countryFilter)
            || co.toLowerCase().includes(countryFilter);
    });

    console.log(`  ✓ Found ${artifacts.length} total artifacts`);
    if (opts.target !== 'all') {
        console.log(`  ✓ ${targetFiltered.length} artifacts match target "${opts.target}"`);
    }
    console.log(`  ✓ ${filtered.length} artifacts match country "${opts.country}"\n`);

    if (filtered.length === 0) {
        console.error('  ❌ No artifacts found for that country.\n');
        process.exit(1);
    }

    // ── 1. Unique buildings ──
    const buildingMap = new Map();
    filtered.forEach(d => {
        const loc = d.data.location;
        const building = loc.building || loc.office || '-';
        if (!buildingMap.has(building)) {
            buildingMap.set(building, {
                building, address: loc.address, postalCode: loc.postalCode,
                city: loc.city, country: loc.countryISOCode, count: 0,
            });
        }
        const entry = buildingMap.get(building);
        entry.count++;
        if (entry.address === '-' && loc.address !== '-') entry.address = loc.address;
        if (entry.postalCode === '-' && loc.postalCode !== '-') entry.postalCode = loc.postalCode;
    });

    const buildingsFile = `${opts.output}_unique_buildings.csv`;
    let csv = 'Building,Address,Postal Code,Country,Artifact Count\n';
    for (const [, b] of [...buildingMap].sort((a, b) => a[0].localeCompare(b[0]))) {
        csv += [b.building, b.address, b.postalCode, b.country, b.count].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(buildingsFile, csv);
    console.log(`  📍 ${buildingsFile}  (${buildingMap.size} unique buildings)`);

    // ── 2. ARN-to-location patch CSV ──
    const patchFile = `${opts.output}_arn_location_patch.csv`;
    let patchCsv = 'ARN,Title,Is Gift,Current Building,Current Floor,Current Room,Current Office,Current Location ID,New Building,New Floor,New Room,New Office\n';
    for (const d of filtered.sort((a, b) => (a.data?.arn || '').localeCompare(b.data?.arn || ''))) {
        const loc = d.data.location || {};
        patchCsv += [
            d.data.arn, d.data.title, d.data.isGift ? 'Yes' : 'No',
            loc.building, loc.floor, loc.room, loc.office, loc.identifier,
            '', '', '', '',
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(patchFile, patchCsv);
    console.log(`  📋 ${patchFile}  (${filtered.length} artifacts)`);

    console.log(`\n  ✅ Location files generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Diff — Masterlist vs CouchDB
// ══════════════════════════════════════════════════════════════

/**
 * Load masterlist Excel into a Map<ARN, record>.
 * Handles the 3-row header in the Audit Copy sheet.
 */
function loadMasterlist(xlsxPath) {
    const xlsx = require('xlsx');
    const wb = xlsx.readFile(xlsxPath);
    const ws = wb.Sheets[wb.SheetNames[0]]; // First sheet
    const raw = xlsx.utils.sheet_to_json(ws, { header: 1 });

    // Find the header row (contains 'ARN')
    let headerIdx = -1;
    for (let i = 0; i < Math.min(10, raw.length); i++) {
        if (raw[i] && raw[i].includes('ARN')) { headerIdx = i; break; }
    }
    if (headerIdx === -1) {
        console.error('  ❌ Could not find header row with "ARN" column in masterlist.\n');
        process.exit(1);
    }

    const headers = raw[headerIdx];
    const map = new Map();

    for (let i = headerIdx + 1; i < raw.length; i++) {
        const row = raw[i];
        if (!row || !row[1]) continue; // col 1 = ARN
        const record = {};
        headers.forEach((h, j) => {
            if (h && row[j] !== undefined && row[j] !== null) {
                record[h] = String(row[j]).replace(/^'/, '').trim(); // strip leading apostrophe
            }
        });
        if (record.ARN) map.set(record.ARN, record);
    }
    return map;
}

/**
 * Build a comparable record from a CouchDB document.
 */
function cdbToComparable(doc) {
    const d = doc.data || {};
    const loc = d.location || {};
    return {
        ARN: d.arn || '',
        Title: d.title || '',
        Artist: d.artist?.name || '',
        Medium: d.medium || '',
        'Entity Code': d.coCode || '',
        Country: loc.countryISOCode || '',
        Entity: d.entity || '',
        Status: d.status || '',
        'Building Name': loc.building || '',
        'Office Name': loc.office || '',
        Floor: String(loc.floor || ''),
        Room: loc.room || '',
        Address: loc.address || '',
        'Postal Code': String(loc.postalCode || ''),
        Category: d.category || '',
    };
}

function runDiffNew(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');
    const cdbMap = new Map();
    artifacts.forEach(d => { if (d.data?.arn) cdbMap.set(d.data.arn, d); });
    console.log(`  ✓ ${cdbMap.size} ARNs in CouchDB\n`);

    // Filter masterMap and cdbMap keys by target
    const masterKeys = [...masterMap.keys()].filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));
    const cdbKeys = [...cdbMap.keys()].filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));

    if (opts.target !== 'all') {
        console.log(`  ✓ ${masterKeys.length} masterlist ARNs match target "${opts.target}"`);
        console.log(`  ✓ ${cdbKeys.length} CouchDB ARNs match target "${opts.target}"\n`);
    }

    const newARNs = masterKeys.filter(a => !cdbMap.has(a)).sort();
    const removedARNs = cdbKeys.filter(a => !masterMap.has(a)).sort();

    // Write new ARNs CSV
    const newFile = `${opts.output}_new_arns.csv`;
    let newCsv = 'ARN,Title,Artist,Entity Code,Country,Entity,Status,Building Name,Office Name,Floor,Room\n';
    for (const arn of newARNs) {
        const r = masterMap.get(arn);
        newCsv += [r.ARN, r.Title, r.Artist, r['Entity Code'], r.Country, r.Entity, r.Status,
            r['Building Name'], r['Office Name'], r.Floor, r.Room].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(newFile, newCsv);
    console.log(`  🆕 ${newFile}  (${newARNs.length} new ARNs)`);

    // Write removed ARNs CSV
    const removedFile = `${opts.output}_removed_arns.csv`;
    let removedCsv = 'ARN,Title,Artist,Entity Code,Status,Building Name\n';
    for (const arn of removedARNs) {
        const c = cdbToComparable(cdbMap.get(arn));
        removedCsv += [c.ARN, c.Title, c.Artist, c['Entity Code'], c.Status, c['Building Name']].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(removedFile, removedCsv);
    console.log(`  🗑️  ${removedFile}  (${removedARNs.length} in CouchDB but not in masterlist)`);

    console.log(`\n  ✅ Diff (new/removed) complete.\n`);
}

function runDiffUpdates(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');
    const cdbMap = new Map();
    artifacts.forEach(d => { if (d.data?.arn) cdbMap.set(d.data.arn, d); });
    console.log(`  ✓ ${cdbMap.size} ARNs in CouchDB\n`);

    const inBoth = [...masterMap.keys()].filter(a => cdbMap.has(a))
        .filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));

    if (opts.target !== 'all') {
        console.log(`  ✓ ${inBoth.length} overlapping ARNs match target "${opts.target}"\n`);
    }

    // Generic subfield noise normalization
    const denoise = v => String(v || '').replace(/^'+/, '')       // remove Excel leading apostrophe
        .replace(/['‘’]/g, '')    // strip curly/straight apostrophes (possessives: "BM's" -> "BMs")
        .replace(/[“”"]/g, '')    // strip double-quote variants
        .replace(/[()]/g, '')              // strip parens
        .trim()
        .toLowerCase()
        .replace(/^0+([1-9]\d*)$/, '$1')                     // strip numeric leading zeros: "01" -> "1"
        .replace(/^(level|lvl|flr|floor|blk|block)\s*/, '')  // strip floor prefix keywords
        .replace(/\s*\/\s*/g, '/')       // normalize spaces around slash: 'A/ B' -> 'A/B'
        .replace(/\s+/g, ' ')             // collapse whitespace
        .replace(/^-$/, '');              // bare dash -> empty

    // Stronger building-name-specific normalization to avoid noise false positives
    const denoiseBuilding = v => {
        let s = String(v || '').replace(/^'+/, '')
            .replace(/['‘’]/g, '')
            .replace(/[“”"]/g, '')
            .replace(/[.,;!]/g, '')        // strip punctuation
            .replace(/[()[\]{}]/g, '')     // strip all bracket types
            .trim()
            .toLowerCase();
        // Expand common abbreviations
        s = s
            .replace(/\bbldg\.?\b/g, 'building')
            .replace(/\bblk\.?\b/g, 'block')
            .replace(/\bst\.?\b/g, 'street')
            .replace(/\brd\.?\b/g, 'road')
            .replace(/\bave\.?\b/g, 'avenue')
            .replace(/\bdr\.?\b/g, 'drive')
            .replace(/\bpl\.?\b/g, 'place')
            .replace(/\bctr\.?\b/g, 'centre')
            .replace(/\bcenter\b/g, 'centre')
            .replace(/\bno\.?\s*/g, '')   // "No. 1" -> "1"
            .replace(/#\s*/g, '')            // "#1" -> "1"
            .replace(/^0+([1-9]\d*)$/, '$1'); // strip numeric leading zeros
        // Normalize separators: slash / dash / & -> single space
        s = s.replace(/[\/\-&]+/g, ' ');
        // Collapse whitespace; bare dash -> empty
        s = s.replace(/\s+/g, ' ').trim().replace(/^-$/, '');
        return s;
    };

    const buildingMoves = [];
    const withinBuildingMoves = [];

    const subfields = ['Office Name', 'Floor', 'Room', 'Address', 'Postal Code'];

    for (const arn of inBoth.sort()) {
        const master = masterMap.get(arn);
        const cdb = cdbToComparable(cdbMap.get(arn));

        const mb = denoiseBuilding(master['Building Name']);
        const cb = denoiseBuilding(cdb['Building Name']);

        // 1. Cross-building move: building names differ even after aggressive denoising
        if (mb !== cb) {
            buildingMoves.push({ arn, master, cdb });
            continue;
        }

        // 2. Within-building move: building matches after denoising, but subfields differ
        const changedSubfields = [];
        for (const f of subfields) {
            const mv = denoise(master[f]);
            const cv = denoise(cdb[f]);
            if (mv !== cv) {
                changedSubfields.push(f);
            }
        }

        if (changedSubfields.length > 0) {
            withinBuildingMoves.push({ arn, master, cdb, changedSubfields });
        }
    }

    // Write Building Moves CSV
    const bMoveFile = `${opts.output}_building_moves.csv`;
    let bCsv = 'ARN,Title,Artist,CouchDB Building,Masterlist Building,CouchDB Office,Masterlist Office,CouchDB Floor,Masterlist Floor,CouchDB Room,Masterlist Room\n';
    for (const { arn, master, cdb } of buildingMoves) {
        bCsv += [
            arn, master.Title, master.Artist,
            cdb['Building Name'], master['Building Name'],
            cdb['Office Name'], master['Office Name'],
            cdb.Floor, master.Floor,
            cdb.Room, master.Room
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(bMoveFile, bCsv);
    console.log(`  🏢 ${bMoveFile}  (${buildingMoves.length} cross-building moves)`);

    // Write Within Building Moves CSV
    const wMoveFile = `${opts.output}_within_building_moves.csv`;
    let wCsv = 'ARN,Title,Artist,Building Name,Changed Fields,CouchDB Office,Masterlist Office,CouchDB Floor,Masterlist Floor,CouchDB Room,Masterlist Room\n';
    for (const { arn, master, cdb, changedSubfields } of withinBuildingMoves) {
        wCsv += [
            arn, master.Title, master.Artist,
            master['Building Name'] || cdb['Building Name'], changedSubfields.join('; '),
            cdb['Office Name'], master['Office Name'],
            cdb.Floor, master.Floor,
            cdb.Room, master.Room
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(wMoveFile, wCsv);
    console.log(`  🚪 ${wMoveFile}  (${withinBuildingMoves.length} within-building moves)`);

    console.log(`\n  ✅ Diff (updates) complete.\n`);
}


// ══════════════════════════════════════════════════════════════
//  Patch — Apply masterlist updates to CouchDB JSON
// ══════════════════════════════════════════════════════════════

function runPatch(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    // Target filter
    const filteredMaster = new Map();
    for (const [arn, rec] of masterMap) {
        const isGiftArn = arn.startsWith('GRN');
        if (opts.target === 'artwork' && isGiftArn) continue;
        if (opts.target === 'gift' && !isGiftArn) continue;
        filteredMaster.set(arn, rec);
    }
    if (opts.target !== 'all') {
        console.log(`  ✓ ${filteredMaster.size} masterlist ARNs match target "${opts.target}"`);
    }

    console.log(`  📂 Loading ${path.basename(opts.input)}...`);
    const raw = fs.readFileSync(opts.input, 'utf8');
    const db = JSON.parse(raw);

    // Index artifact rows by ARN
    const rowIndex = new Map();
    (db.rows || []).forEach((row, idx) => {
        const arn = row?.doc?.data?.arn;
        if (arn) rowIndex.set(arn, idx);
    });
    console.log(`  ✓ ${rowIndex.size} ARNs indexed in CouchDB JSON\n`);

    // ── PHASE 1: Build diff log and apply changes to in-memory db ──
    const LOC_FIELDS = ['building', 'office', 'floor', 'room', 'address', 'postalCode', 'countryISOCode'];
    const ML_KEYS    = ['Building Name', 'Office Name', 'Floor', 'Room', 'Address', 'Postal Code', 'Country'];

    // diffRows: one row per changed field (for UPDATE), one row per location field (for ADD)
    const diffRows = []; // { arn, type, field, oldValue, newValue }
    let updated = 0;
    let added   = 0;

    for (const [arn, rec] of filteredMaster) {
        const mlLocation = {};
        LOC_FIELDS.forEach((lf, i) => { mlLocation[lf] = rec[ML_KEYS[i]] || ''; });

        if (rowIndex.has(arn)) {
            // ── UPDATE: merge masterlist location into existing doc ──
            const doc  = db.rows[rowIndex.get(arn)].doc;
            const oldLoc = doc.data.location || {};
            const newLoc = Object.assign({}, oldLoc, mlLocation);
            doc.data.location = newLoc;

            let anyChange = false;
            for (const lf of LOC_FIELDS) {
                const oldVal = String(oldLoc[lf] || '');
                const newVal = String(newLoc[lf] || '');
                if (oldVal !== newVal) {
                    diffRows.push({ arn, type: 'update', field: lf, oldValue: oldVal, newValue: newVal });
                    anyChange = true;
                }
            }
            if (anyChange) updated++;

        } else {
            // ── ADD: full record from masterlist ──
            const isGift = arn.startsWith('GRN');
            const now    = new Date().toISOString();
            const newDoc = {
                _id:        `io.uob.resources.artifact#${arn}`,
                identifier: `io.uob.resources.artifact#${arn}`,
                data: {
                    arn,
                    title:       rec['Title']       || '',
                    status:      rec['Status']      || '',
                    artMedium:   rec['Medium']      || '',
                    artCategory: rec['Category']    || '',
                    coCode:      rec['Entity Code'] || '',
                    company:     rec['Entity']      || '',
                    isGift,
                    location: mlLocation,
                },
                metadata: {
                    createdDate: now,
                    docType:     'io.uob.resources.artifact',
                    status:      'io.uob.resources.status.available',
                },
            };
            db.rows.push({ doc: newDoc });
            rowIndex.set(arn, db.rows.length - 1);
            added++;
            // Log all location fields for new ARNs
            for (const lf of LOC_FIELDS) {
                diffRows.push({ arn, type: 'add', field: lf, oldValue: '', newValue: mlLocation[lf] });
            }
        }
    }

    const untouched = (rowIndex.size - added) - filteredMaster.size + added; // CouchDB-only count
    const cdbOnlyCount = Array.from(rowIndex.keys()).filter(a => !filteredMaster.has(a)).length;

    // ── PHASE 2: Write pre-patch diff CSV ──
    const diffFile = opts.output.replace(/\.json$/i, '') + '_patch_diff.csv';
    let diffCsv = 'ARN,Type,Field,Old Value,New Value\n';
    for (const r of diffRows) {
        diffCsv += [r.arn, r.type, r.field, r.oldValue, r.newValue].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(diffFile, diffCsv);
    console.log(`  📋 ${diffFile}  (${diffRows.length} field changes across ${updated + added} ARNs)`);

    // ── Print summary ──
    console.log(`\n  📊 Patch summary:`);
    console.log(`     Location updated : ${updated} ARNs`);
    console.log(`     New ARNs added   : ${added} ARNs`);
    console.log(`     Untouched        : ${cdbOnlyCount} ARNs (CouchDB only)`);

    if (opts.dryRun) {
        console.log(`\n  ℹ️  Dry run — diff CSV written, patched JSON NOT written.\n`);
        return;
    }

    // ── PHASE 3: Write patched JSON ──
    const outPath = path.resolve(opts.output);
    fs.writeFileSync(outPath, JSON.stringify(db, null, 2), 'utf8');
    console.log(`\n  💾 ${outPath}`);

    // ── PHASE 4: Verification — re-read patched JSON and check every diff row ──
    console.log(`\n  🔍 Verifying patched JSON against diff CSV...`);
    const patchedRaw = fs.readFileSync(outPath, 'utf8');
    const patchedDb  = JSON.parse(patchedRaw);
    const patchedIdx = new Map();
    (patchedDb.rows || []).forEach(row => {
        const arn = row?.doc?.data?.arn;
        if (arn) patchedIdx.set(arn, row.doc);
    });

    let pass = 0;
    let fail = 0;
    const failures = [];

    for (const r of diffRows) {
        const doc = patchedIdx.get(r.arn);
        if (!doc) {
            fail++;
            failures.push(`  ❌ ARN ${r.arn}: document not found in patched JSON`);
            continue;
        }
        const actual = String(doc.data?.location?.[r.field] || '');
        if (actual === r.newValue) {
            pass++;
        } else {
            fail++;
            failures.push(`  ❌ ${r.arn} [${r.field}]: expected "${r.newValue}", got "${actual}"`);
        }
    }

    if (fail === 0) {
        console.log(`  ✅ Verification PASSED — all ${pass} field changes confirmed correct.`);
    } else {
        console.log(`  ⚠️  Verification: ${pass} passed, ${fail} FAILED`);
        failures.slice(0, 20).forEach(f => console.log(f));
        if (failures.length > 20) console.log(`  ... and ${failures.length - 20} more failures.`);
    }

    console.log(`\n  ✅ Patch complete.\n`);
}


// ══════════════════════════════════════════════════════════════
//  Patch-Import — Merge custom-column Excel into CouchDB JSON
// ══════════════════════════════════════════════════════════════

// Column index → { label, getter, setter }
// getter(doc)  → current string value from doc
// setter(doc, val) → mutates doc in place
const IMPORT_COL_MAP = [
    // idx  label                    getter                                          setter
    [  1, 'title',                  d => String(d.data?.title || ''),               (d,v) => { d.data.title = v; }],
    [  2, 'artist.name',            d => String(d.data?.artist?.name || d.data?.artist?.nickName || ''),
                                                                                    (d,v) => { if (!d.data.artist) d.data.artist = {}; d.data.artist.name = v; }],
    [  3, 'artMedium',              d => String(d.data?.artMedium || ''),           (d,v) => { d.data.artMedium = v; }],
    [  4, 'coCode',                 d => String(d.data?.coCode || ''),              (d,v) => { d.data.coCode = v; }],
    [  5, 'location.countryISOCode',d => String(d.data?.location?.countryISOCode || ''), (d,v) => { (d.data.location = d.data.location||{}).countryISOCode = v; }],
    [  6, 'company',                d => String(d.data?.company || ''),             (d,v) => { d.data.company = v; }],
    [  7, 'status',                 d => String(d.data?.status || ''),              (d,v) => { d.data.status = v; }],
    [  8, 'location.state',         d => String(d.data?.location?.state || ''),     (d,v) => { (d.data.location = d.data.location||{}).state = v; }],
    [  9, 'location.city',          d => String(d.data?.location?.city || ''),      (d,v) => { (d.data.location = d.data.location||{}).city = v; }],
    [ 10, 'location.postalCode',    d => String(d.data?.location?.postalCode || ''), (d,v) => { (d.data.location = d.data.location||{}).postalCode = v; }],
    [ 11, 'location.address',       d => String(d.data?.location?.address || ''),   (d,v) => { (d.data.location = d.data.location||{}).address = v; }],
    [ 12, 'location.building',      d => String(d.data?.location?.building || ''),  (d,v) => { (d.data.location = d.data.location||{}).building = v; }],
    [ 13, 'location.office',        d => String(d.data?.location?.office || ''),    (d,v) => { (d.data.location = d.data.location||{}).office = v; }],
    [ 14, 'location.floor',         d => String(d.data?.location?.floor || ''),     (d,v) => { (d.data.location = d.data.location||{}).floor = v; }],
    [ 15, 'location.room',          d => String(d.data?.location?.room || ''),      (d,v) => { (d.data.location = d.data.location||{}).room = v; }],
    [ 16, 'artHeight',              d => String(d.data?.artHeight || ''),            (d,v) => { d.data.artHeight = v; }],
    [ 17, 'artWidth',               d => String(d.data?.artWidth || ''),             (d,v) => { d.data.artWidth = v; }],
    [ 18, 'artDepth',               d => String(d.data?.artDepth || ''),             (d,v) => { d.data.artDepth = v; }],
    [ 19, 'artFrameHeight',         d => String(d.data?.artFrameHeight || ''),       (d,v) => { d.data.artFrameHeight = v; }],
    [ 20, 'artFrameWidth',          d => String(d.data?.artFrameWidth || ''),        (d,v) => { d.data.artFrameWidth = v; }],
    [ 21, 'artFrameDepth',          d => String(d.data?.artFrameDepth || ''),        (d,v) => { d.data.artFrameDepth = v; }],
    [ 22, 'artOrientation',         d => String(d.data?.artOrientation || ''),       (d,v) => { d.data.artOrientation = v; }],
    [ 23, 'artCategory',            d => String(d.data?.artCategory || ''),          (d,v) => { d.data.artCategory = v; }],
    [ 24, 'internal',               d => String(d.data?.internal || ''),             (d,v) => { d.data.internal = v; }],
    [ 25, 'artMinValue',            d => String(d.data?.artMinValue || ''),          (d,v) => { d.data.artMinValue = v; }],
    [ 26, 'artMaxValue',            d => String(d.data?.artMaxValue || ''),          (d,v) => { d.data.artMaxValue = v; }],
    [ 27, 'artValuedDate',          d => String(d.data?.artValuedDate || ''),        (d,v) => { d.data.artValuedDate = v; }],
    [ 28, 'artValuedBy',            d => String(d.data?.artValuedBy || ''),          (d,v) => { d.data.artValuedBy = v; }],
    [ 29, 'artValuationNotes',      d => String(d.data?.artValuationNotes || ''),    (d,v) => { d.data.artValuationNotes = v; }],
    [ 30, 'artCondition',           d => String(d.data?.artCondition || ''),         (d,v) => { d.data.artCondition = v; }],
    [ 31, 'artConditionComment',    d => String(d.data?.artConditionComment || ''),  (d,v) => { d.data.artConditionComment = v; }],
    [ 32, 'artFrameCondition',      d => String(d.data?.artFrameCondition || ''),    (d,v) => { d.data.artFrameCondition = v; }],
    [ 33, 'artMountCondition',      d => String(d.data?.artMountCondition || ''),    (d,v) => { d.data.artMountCondition = v; }],
    [ 34, 'artTags',                d => String(d.data?.artTags || ''),              (d,v) => { d.data.artTags = v; }],
    [ 35, 'year',                   d => String(d.data?.year || ''),                 (d,v) => { d.data.year = v; }],
    [ 36, 'acquisitionDate',        d => String(d.data?.acquisitionDate || ''),      (d,v) => { d.data.acquisitionDate = v; }],
    [ 37, 'artworkWriteup',         d => String(d.data?.artworkWriteup || ''),       (d,v) => { d.data.artworkWriteup = v; }],
    [ 38, 'artworkAwards',          d => String(d.data?.artworkAwards || ''),        (d,v) => { d.data.artworkAwards = v; }],
];

function runPatchImport(opts) {
    if (!opts.excel) {
        console.error('  ❌ Missing --excel <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    // ── Load Excel by column index ──
    const xlsx = require('xlsx');
    const wb   = xlsx.readFile(opts.excel);
    const sheetName = typeof opts.sheet === 'string'
        ? opts.sheet
        : wb.SheetNames[opts.sheet] || wb.SheetNames[0];
    if (!wb.Sheets[sheetName]) {
        console.error(`  ❌ Sheet "${sheetName}" not found in ${path.basename(opts.excel)}\n`);
        process.exit(1);
    }
    console.log(`  📊 Excel: ${path.basename(opts.excel)}  [sheet: ${sheetName}]`);
    // Helper: convert an Excel cell value to a clean string.
    // Date cells come back as numeric serials OR formatted strings (e.g. "30-Nov-24").
    const DATE_COLS = new Set([27, 36]); // value date, acquisition date (year col 35 is a plain number)
    const excelSerialToISO = (serial) => {
        // xlsx uses the 1900 date system (serial 1 = 1900-01-01, but 1900 is wrongly
        // treated as a leap year, so the epoch offset is Dec 30, 1899).
        const msPerDay   = 86400000;
        const excelEpoch = Date.UTC(1899, 11, 30); // Dec 30 1899
        return new Date(excelEpoch + Math.round(serial) * msPerDay).toISOString();
    };
    // Parse "dd-mmm-yy" / "dd-mmm-yyyy" / "dd/mmm/yy" etc. → ISO string, or null if not matched.
    const MON = { jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11 };
    const parseDmyStr = (s) => {
        const m = /^(\d{1,2})[\/\-\s]([A-Za-z]{3})[\/\-\s](\d{2,4})$/.exec(String(s).trim());
        if (!m) return null;
        const mon = MON[m[2].toLowerCase()];
        if (mon === undefined) return null;
        let yr = +m[3];
        if (yr < 100) yr += (yr < 30 ? 2000 : 1900); // "24" → 2024, "99" → 1999
        return new Date(Date.UTC(yr, mon, +m[1])).toISOString();
    };
    const cellToStr = (v, colIdx) => {
        if (v === null || v === undefined || v === '') return '';
        // Handle JS Date objects (returned when cellDates:true or auto-detected)
        if (v instanceof Date) return v.toISOString();
        if (DATE_COLS.has(colIdx)) {
            // 1. Numeric serial (e.g. 45292)
            const asNum = typeof v === 'number' ? v : Number(v);
            if (!isNaN(asNum) && asNum > 59) return excelSerialToISO(asNum);
            // 2. Formatted date string (e.g. "30-Nov-24")
            const parsed = parseDmyStr(v);
            if (parsed) return parsed;
        }
        return String(v).replace(/^'+/, '').trim();
    };

    const rawRows = xlsx.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, defval: '' });

    // Skip header rows (headerRow is 1-based)
    const dataRows = rawRows.slice(opts.headerRow);
    const C = opts.colOffset || 0; // column shift (e.g. 1 when sheet has a leading comment col)
    const excelMap = new Map(); // ARN -> row array
    for (const row of dataRows) {
        const arn = String(row[C] || '').replace(/^'+/, '').trim(); // ARN at col 0 + offset
        if (!arn) continue;
        excelMap.set(arn, row);
    }
    console.log(`  ✓ ${excelMap.size} ARNs read from Excel${C ? ` (col-offset: ${C})` : ''}`);


    // ── Load CouchDB JSON ──
    console.log(`  📂 Loading ${path.basename(opts.input)}...`);
    const raw = fs.readFileSync(opts.input, 'utf8');
    const db  = JSON.parse(raw);

    // Index by ARN
    const rowIndex = new Map();
    (db.rows || []).forEach((row, idx) => {
        const arn = row?.doc?.data?.arn;
        if (arn) rowIndex.set(arn, idx);
    });
    console.log(`  ✓ ${rowIndex.size} ARNs indexed in CouchDB JSON\n`);

    // ── PHASE 1: Compute diff + apply changes in-memory ──
    const diffRows = []; // { arn, type, field, oldValue, newValue }
    let updated = 0, added = 0;

    // For existing ARNs only these column indices (location fields) are applied.
    // All other fields are left untouched to avoid overwriting verified CouchDB data.
    const LOCATION_COLS = new Set([5, 8, 9, 10, 11, 12, 13, 14, 15]);

    for (const [arn, excelRow] of excelMap) {
        if (rowIndex.has(arn)) {
            // UPDATE existing document — location fields ONLY
            const doc = db.rows[rowIndex.get(arn)].doc;
            let anyChange = false;
            // For date fields compare only YYYY-MM-DD to avoid timezone-induced false diffs
            const dateKey = (v) => (v && v.length >= 10) ? v.slice(0, 10) : v;

            for (const [colIdx, label, getter, setter] of IMPORT_COL_MAP) {
                if (!LOCATION_COLS.has(colIdx)) continue; // non-location fields: skip for existing ARNs
                const newVal = cellToStr(excelRow[colIdx + C], colIdx);
                if (newVal === '') continue; // skip empty cells — do not overwrite with blank
                const oldVal = getter(doc);
                // For date columns, only flag as changed if the calendar date differs
                const differs = DATE_COLS.has(colIdx)
                    ? dateKey(oldVal) !== dateKey(newVal)
                    : oldVal !== newVal;
                if (differs) {
                    diffRows.push({ arn, type: 'update', field: label, oldValue: oldVal, newValue: newVal });
                    setter(doc, newVal);
                    anyChange = true;
                }
            }
            if (anyChange) updated++;

        } else {
            // ADD new document — build from all columns
            const isGift = arn.startsWith('GRN');
            const now    = new Date().toISOString();
            const get    = (idx) => cellToStr(excelRow[idx + C], idx);
            const newDoc = {
                _id:        `io.uob.resources.artifact#${arn}`,
                identifier: `io.uob.resources.artifact#${arn}`,
                data: {
                    arn,
                    title:               get(1),
                    artist:              { name: get(2) },
                    artMedium:           get(3),
                    coCode:              get(4),
                    company:             get(6),
                    status:              get(7),
                    artHeight:           get(16),
                    artWidth:            get(17),
                    artDepth:            get(18),
                    artFrameHeight:      get(19),
                    artFrameWidth:       get(20),
                    artFrameDepth:       get(21),
                    artOrientation:      get(22),
                    artCategory:         get(23),
                    internal:            get(24),
                    artMinValue:         get(25),
                    artMaxValue:         get(26),
                    artValuedDate:       get(27),
                    artValuedBy:         get(28),
                    artValuationNotes:   get(29),
                    artCondition:        get(30),
                    artConditionComment: get(31),
                    artFrameCondition:   get(32),
                    artMountCondition:   get(33),
                    artTags:             get(34),
                    year:                get(35),
                    acquisitionDate:     get(36),
                    artworkWriteup:      get(37),
                    artworkAwards:       get(38),
                    isGift,
                    location: {
                        countryISOCode: get(5),
                        state:          get(8),
                        city:           get(9),
                        postalCode:     get(10),
                        address:        get(11),
                        building:       get(12),
                        office:         get(13),
                        floor:          get(14),
                        room:           get(15),
                    },
                },
                metadata: {
                    createdDate: now,
                    docType:     'io.uob.resources.artifact',
                    status:      'io.uob.resources.status.available',
                },
            };
            db.rows.push({ doc: newDoc });
            rowIndex.set(arn, db.rows.length - 1);
            added++;
            // Log all non-empty fields for new ARN (use cellToStr so dates are converted)
            for (const [colIdx, label] of IMPORT_COL_MAP) {
                const v = cellToStr(excelRow[colIdx + C] ?? '', colIdx);
                diffRows.push({ arn, type: 'add', field: label, oldValue: '', newValue: v });
            }
        }
    }

    const cdbOnlyCount = Array.from(rowIndex.keys()).filter(a => !excelMap.has(a)).length;

    // ── PHASE 2: Write diff CSV ──
    const diffFile = opts.output.replace(/\.json$/i, '') + '_import_diff.csv';
    let diffCsv = 'ARN,Type,Field,Old Value,New Value\n';
    for (const r of diffRows) {
        diffCsv += [r.arn, r.type, r.field, r.oldValue, r.newValue].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(diffFile, diffCsv);
    console.log(`  📋 ${diffFile}  (${diffRows.length} field changes across ${updated + added} ARNs)`);
    console.log(`\n  📊 Import summary:`);
    console.log(`     Updated  : ${updated} ARNs`);
    console.log(`     Added    : ${added} ARNs`);
    console.log(`     Untouched: ${cdbOnlyCount} ARNs (CouchDB only)`);

    if (opts.dryRun) {
        console.log(`\n  ℹ️  Dry run — diff CSV written, output JSON NOT written.\n`);
        return;
    }

    // ── PHASE 3: Write output JSON ──
    const outPath = path.resolve(opts.output);
    fs.writeFileSync(outPath, JSON.stringify(db, null, 2), 'utf8');
    console.log(`\n  💾 ${outPath}`);

    // ── PHASE 4: Verify every diff row against the written file ──
    console.log(`\n  🔍 Verifying output JSON against diff CSV...`);
    const verifyDb  = JSON.parse(fs.readFileSync(outPath, 'utf8'));
    const verifyIdx = new Map();
    (verifyDb.rows || []).forEach(row => {
        const a = row?.doc?.data?.arn;
        if (a) verifyIdx.set(a, row.doc);
    });

    let pass = 0, fail = 0;
    const failures = [];

    for (const r of diffRows) {
        if (r.newValue === '') continue; // blank skipped fields — not applied
        const doc = verifyIdx.get(r.arn);
        if (!doc) { fail++; failures.push(`  ❌ ARN ${r.arn}: not found in output JSON`); continue; }
        // Use the getter from IMPORT_COL_MAP to read back the value
        const mapEntry = IMPORT_COL_MAP.find(([,label]) => label === r.field);
        if (!mapEntry) continue;
        const actual = mapEntry[2](doc);
        if (actual === r.newValue) { pass++; }
        else { fail++; failures.push(`  ❌ ${r.arn} [${r.field}]: expected "${r.newValue}", got "${actual}"`); }
    }

    if (fail === 0) {
        console.log(`  ✅ Verification PASSED — all ${pass} field changes confirmed correct.`);
    } else {
        console.log(`  ⚠️  Verification: ${pass} passed, ${fail} FAILED`);
        failures.slice(0, 20).forEach(f => console.log(f));
        if (failures.length > 20) console.log(`  ... and ${failures.length - 20} more.`);
    }

    console.log(`\n  ✅ Import complete.\n`);
}


// ══════════════════════════════════════════════════════════════
//  Patch-Images — Register local image files into CouchDB JSON
// ══════════════════════════════════════════════════════════════

const IMAGE_EXTS = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp', '.tiff', '.tif', '.bmp']);

function extToMime(ext) {
    const map = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
                  '.gif': 'image/gif',  '.webp': 'image/webp', '.tiff': 'image/tiff',
                  '.tif': 'image/tiff', '.bmp':  'image/bmp' };
    return map[ext.toLowerCase()] || 'image/jpeg';
}

function readDirRecursive(dir, base = '') {
    let results = [];
    const files = fs.readdirSync(dir, { withFileTypes: true });
    for (const file of files) {
        const fullPath = path.join(dir, file.name);
        const relPath = base ? path.join(base, file.name) : file.name;
        if (file.isDirectory()) {
            results = results.concat(readDirRecursive(fullPath, relPath));
        } else {
            results.push(relPath.split(path.sep).join('/')); // Force POSIX slashes for URLs
        }
    }
    return results;
}

function runPatchImages(opts) {
    if (!opts.images) {
        console.error('  ❌ Missing --images <dir>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    // ── Scan directory ──
    const imgDir = opts.images;
    console.log(`  🖼  Scanning images: ${imgDir}`);
    let allFiles;
    try {
        allFiles = readDirRecursive(imgDir);
    } catch (e) {
        console.error(`  ❌ Cannot read directory: ${imgDir}\n`);
        process.exit(1);
    }

    // Group files by ARN prefix  (filename must start with ARN then _ or .)
    const arnImages = new Map(); // ARN -> sorted string[] of filenames
    for (const filename of allFiles) {
        const ext = path.extname(filename).toLowerCase();
        if (!IMAGE_EXTS.has(ext)) continue;
        const base = path.basename(filename, ext);
        // Extract ARN: everything before the first _ or the whole base if no _
        const underscoreIdx = base.indexOf('_');
        const arn = underscoreIdx === -1 ? base : base.slice(0, underscoreIdx);
        if (!arn) continue;
        if (!arnImages.has(arn)) arnImages.set(arn, []);
        arnImages.get(arn).push(filename);
    }
    // Sort filenames per ARN for deterministic order
    for (const [arn, files] of arnImages) arnImages.set(arn, files.sort());
    console.log(`  ✓ ${arnImages.size} ARNs found across ${[...arnImages.values()].reduce((s,a)=>s+a.length,0)} image files`);

    // ── Load CouchDB JSON ──
    console.log(`  📂 Loading ${path.basename(opts.input)}...`);
    const raw = fs.readFileSync(opts.input, 'utf8');
    const db  = JSON.parse(raw);
    const rowIndex = new Map();
    (db.rows || []).forEach((row, idx) => {
        const arn = row?.doc?.data?.arn;
        if (arn) rowIndex.set(arn, idx);
    });
    console.log(`  ✓ ${rowIndex.size} ARNs indexed in CouchDB JSON\n`);

    // ── PHASE 1: Compute changes + apply in-memory ──
    const now = new Date().toISOString();
    const diffRows = []; // { arn, action, imageCount, filenames, thumbnail }
    let updated = 0, skipped = 0;

    for (const [arn, files] of arnImages) {
        if (!rowIndex.has(arn)) {
            skipped++;
            diffRows.push({ arn, action: 'no_match', imageCount: files.length,
                            filenames: files.join('; '), thumbnail: '' });
            continue;
        }

        const doc = db.rows[rowIndex.get(arn)].doc;
        const thumbnailFile = files[0]; // first alphabetically = thumbnail
        const ext = path.extname(thumbnailFile).toLowerCase();

        // Build images array — url stored as relative path within images dir
        const newImages = files.map(f => ({
            contentType: extToMime(path.extname(f).toLowerCase()),
            createdDate: now,
            name:        f,
            url:         f,   // local filename; consumer maps to actual path
        }));

        const newThumbnail = {
            contentType: extToMime(ext),
            createdDate: now,
            name:        thumbnailFile,
            url:         thumbnailFile,
        };

        doc.data.images    = newImages;
        doc.data.thumbnail = newThumbnail;
        updated++;
        diffRows.push({ arn, action: 'updated', imageCount: files.length,
                        filenames: files.join('; '), thumbnail: thumbnailFile });
    }

    // ── PHASE 2: Write diff CSV ──
    const diffFile = opts.output.replace(/\.json$/i, '') + '_images_diff.csv';
    let diffCsv = 'ARN,Action,Image Count,Filenames,Thumbnail\n';
    for (const r of diffRows) {
        diffCsv += [r.arn, r.action, r.imageCount, r.filenames, r.thumbnail].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(diffFile, diffCsv);
    console.log(`  📋 ${diffFile}  (${diffRows.length} ARNs logged)`);
    console.log(`\n  📊 Image patch summary:`);
    console.log(`     Updated  : ${updated} ARNs`);
    console.log(`     No match : ${skipped} ARNs (image files with no CouchDB record)`);
    console.log(`     Untouched: ${rowIndex.size - updated} ARNs (no images provided)`);

    if (opts.dryRun) {
        console.log(`\n  ℹ️  Dry run — diff CSV written, output JSON NOT written.\n`);
        return;
    }

    // ── PHASE 3: Write output JSON ──
    const outPath = path.resolve(opts.output);
    fs.writeFileSync(outPath, JSON.stringify(db, null, 2), 'utf8');
    console.log(`\n  💾 ${outPath}`);

    // ── PHASE 4: Verify ──
    console.log(`\n  🔍 Verifying output JSON...`);
    const verifyDb  = JSON.parse(fs.readFileSync(outPath, 'utf8'));
    const verifyIdx = new Map();
    (verifyDb.rows || []).forEach(row => {
        const a = row?.doc?.data?.arn;
        if (a) verifyIdx.set(a, row.doc);
    });

    let pass = 0, fail = 0;
    const failures = [];
    for (const r of diffRows) {
        if (r.action !== 'updated') continue;
        const doc = verifyIdx.get(r.arn);
        if (!doc) { fail++; failures.push(`  ❌ ${r.arn}: not found in output`); continue; }
        const imgCount = (doc.data?.images || []).length;
        const thumb    = doc.data?.thumbnail?.name || '';
        if (imgCount === r.imageCount && thumb === r.thumbnail) { pass++; }
        else { fail++; failures.push(`  ❌ ${r.arn}: expected ${r.imageCount} images/${r.thumbnail}, got ${imgCount}/${thumb}`); }
    }

    if (fail === 0) {
        console.log(`  ✅ Verification PASSED — all ${pass} ARNs have correct image data.`);
    } else {
        console.log(`  ⚠️  Verification: ${pass} passed, ${fail} FAILED`);
        failures.slice(0, 20).forEach(f => console.log(f));
    }

    console.log(`\n  ✅ Image patch complete.\n`);
}


// ══════════════════════════════════════════════════════════════
//  Match-Images — Match image filenames to artwork titles
// ══════════════════════════════════════════════════════════════

// Sanitize a string for title-matching: lowercase, strip extension,
// replace ANY non-alphanumeric character with a space, collapse spaces.
// Uses Unicode property escapes (\p{L} for letters, \p{N} for numbers)
// to safely preserve Chinese, Thai, Vietnamese, etc.
function sanitizeForMatch(s) {
    return String(s || '')
        .toLowerCase()
        .replace(/[^\p{L}\p{N}]+/gu, ''); // Completely strip all spaces and punctuation
}



function runMatchImages(opts) {
    if (!opts.images) {
        console.error('  ❌ Missing --images <dir>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    // ── Scan directory ──
    const imgDir = opts.images;
    console.log(`  🖼  Scanning images: ${imgDir}`);
    let allFiles;
    try {
        allFiles = readDirRecursive(imgDir);
    } catch (e) {
        console.error(`  ❌ Cannot read directory: ${imgDir}\n`);
        process.exit(1);
    }
    const imageFiles = allFiles.filter(f => IMAGE_EXTS.has(path.extname(f).toLowerCase()));
    console.log(`  ✓ ${imageFiles.length} image files found`);

    // ── Load CouchDB JSON ──
    console.log(`  📂 Loading ${path.basename(opts.input)}...`);
    const raw = fs.readFileSync(opts.input, 'utf8');
    const db  = JSON.parse(raw);

    // Build title index: sanitizedTitle → [{ arn, title, year, country, rowIdx }]
    const titleIndex = new Map(); // sanitized → array of matches
    const allYears = new Set();
    const allCountries = new Set();
    (db.rows || []).forEach((row, idx) => {
        const doc  = row?.doc;
        if (doc?.metadata?.docType !== 'io.uob.resources.artifact') return;
        const arn   = doc?.data?.arn;
        const title = doc?.data?.title;
        if (!arn || !title) return;
        
        let year = String(doc?.data?.year || '');
        if (year.length >= 4) {
            const d = new Date(year);
            // Parse into local 4-digit year (e.g. "2021-12-31T16:00:00.000Z" -> "2022" in SGT)
            if (!isNaN(d.getTime())) year = String(d.getFullYear());
            else year = year.substring(0, 4); // fallback
        }
        
        const country = String(doc?.data?.location?.countryISOCode || '');
        const coCode = String(doc?.data?.coCode || '');

        const key = sanitizeForMatch(title);
        if (!titleIndex.has(key)) titleIndex.set(key, []);
        titleIndex.get(key).push({ arn, title, sanitizedTitle: key, year, country, coCode, rowIdx: idx });
        
        if (year) allYears.add(year.toLowerCase());
        if (country) allCountries.add(country.toLowerCase());
    });
    console.log(`  ✓ ${titleIndex.size} unique sanitized titles indexed\n`);

    // ── PHASE 1: Match every image file ──
    const now = new Date().toISOString();
    const reportRows = []; // { filename, arn, matchedTitle, confidence, action }
    const updates    = new Map(); // arn → [filenames]
    let exactMatches = 0, partialMatches = 0, noMatches = 0;

    for (const filename of imageFiles.sort()) {
        const baseName = path.basename(filename, path.extname(filename));
        const folderName = path.dirname(filename);
        const folderLower = folderName.toLowerCase();
        
        const sanitizedFull = sanitizeForMatch(baseName);
        const allDocs = Array.from(titleIndex.values()).flat();

        let candidates = [];
        let matchType = '';

        // EXTREMELY STRICT FILTER FIRST:
        // Create a pool of candidates that definitively belong to the folder's Country and Year.
        const countryToCoCode = {
            'singapore': 'UOB SG',
            'indonesia': 'UOB ID',
            'malaysia': 'UOB MY',
            'thailand': 'UOB TH',
            'hong kong': 'UOB HK',
            'hongkong': 'UOB HK',
            'china': 'UOB CN',
            'vietnam': 'UOB VN',
            'viet nam': 'UOB VN',
            'philippines': 'UOB PH',
            'australia': 'UOB AUS',
            'myanmar': 'UOB MM'
        };

        let expectedCoCode = null;
        for (const [c, code] of Object.entries(countryToCoCode)) {
            if (folderLower.includes(c)) {
                expectedCoCode = code;
                break;
            }
        }

        const eligibleDocs = [];
        const seenArns = new Set();
        const sanitizedFolder = sanitizeForMatch(folderName);
        for (const c of allDocs) {
            if (!seenArns.has(c.arn)) {
                seenArns.add(c.arn);
                const sanitizedYear = c.year ? sanitizeForMatch(c.year) : '';
                
                const hasYear = sanitizedYear ? sanitizedFolder.includes(sanitizedYear) : false;
                const hasCoCode = expectedCoCode ? c.coCode === expectedCoCode : false;
                
                if (hasYear && hasCoCode) {
                    eligibleDocs.push(c);
                }
            }
        }

        // Step 1: Raw Exact Match
        candidates = eligibleDocs.filter(d => d.title === baseName);
        if (candidates.length > 0) {
            matchType = 'exact match';
        } else {
            // Step 2: Sanitized Exact Match
            candidates = eligibleDocs.filter(d => d.sanitizedTitle === sanitizedFull);
            if (candidates.length > 0) {
                matchType = 'sanitized exact match';
            } else {
                // Step 3: Prefix strip + sanitize + contains
                const lastUnder = baseName.lastIndexOf('_');
                const sanitizedStripped = lastUnder !== -1 ? sanitizeForMatch(baseName.substring(lastUnder + 1)) : '';
                
                candidates = eligibleDocs.filter(d => {
                    if (d.sanitizedTitle.length < 3) return false;
                    
                    // 1. Image name contains JSON title
                    if (sanitizedFull.includes(d.sanitizedTitle)) return true;
                    
                    // 2. JSON title contains FULL Image name (e.g. JSON: 'Titian Sunyata', Image: 'Titian')
                    if (sanitizedFull.length > 2 && d.sanitizedTitle.includes(sanitizedFull)) return true;
                    
                    // 3. JSON title contains STRIPPED Image name (e.g. JSON: 'Titian Sunyata', Image: 'Prefix_Titian')
                    if (sanitizedStripped.length > 2 && d.sanitizedTitle.includes(sanitizedStripped)) return true;
                    
                    return false;
                });
                if (candidates.length > 0) matchType = 'contains match';
            }
        }

        if (candidates.length === 1) {
            // Unambiguous 100% match!
            const { arn, title } = candidates[0];
            reportRows.push({ filename, arn, matchedTitle: title, confidence: 100, action: `update (${matchType})` });
            if (!updates.has(arn)) updates.set(arn, []);
            updates.get(arn).push(filename);
            exactMatches++;
        } else if (candidates.length > 1) {
            // Ambiguous
            const arns = candidates.map(c => c.arn).join('; ');
            reportRows.push({ filename, arn: arns, matchedTitle: candidates[0].title,
                confidence: 0, action: `ambiguous - matched ${candidates.length} ARNs` });
            partialMatches++;
        } else {
            // No match found that meets all 3 criteria (Title + Year + Country)
            reportRows.push({ filename, arn: '', matchedTitle: '',
                confidence: 0, action: 'no match - manual review required' });
            noMatches++;
        }
    }

    // ── PHASE 2: Apply updates in-memory ──
    const rowIndex = new Map();
    (db.rows || []).forEach((row, idx) => {
        const arn = row?.doc?.data?.arn;
        if (arn) rowIndex.set(arn, idx);
    });

    for (const [arn, files] of updates) {
        if (!rowIndex.has(arn)) continue;
        const doc = db.rows[rowIndex.get(arn)].doc;
        const sortedFiles = [...files].sort();
        const thumbnailFile = sortedFiles[0];
        const ext = path.extname(thumbnailFile).toLowerCase();

        doc.data.images = sortedFiles.map(f => ({
            contentType: extToMime(path.extname(f).toLowerCase()),
            createdDate: now,
            name: f,
            url:  f,
        }));
        doc.data.thumbnail = {
            contentType: extToMime(ext),
            createdDate: now,
            name: thumbnailFile,
            url:  thumbnailFile,
        };
    }

    // ── PHASE 3: Write match report CSV ──
    const reportFile = opts.output.replace(/\.json$/i, '') + '_match_report.csv';
    let csv = 'Filename,ARN,Matched Title,Confidence (%),Action\n';
    for (const r of reportRows) {
        csv += [r.filename, r.arn, r.matchedTitle, r.confidence, r.action].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(reportFile, csv);
    console.log(`  📋 ${reportFile}`);
    console.log(`\n  📊 Match summary:`);
    console.log(`     ✅ Exact matches (100%)  : ${exactMatches}`);
    console.log(`     ⚠️  Partial / ambiguous   : ${partialMatches}`);
    console.log(`     ❌ No match              : ${noMatches}`);
    console.log(`     📝 JSON updates queued   : ${updates.size} ARNs`);

    if (opts.dryRun) {
        console.log(`\n  ℹ️  Dry run — report CSV written, output JSON NOT written.\n`);
        return;
    }

    // ── PHASE 4: Write output JSON ──
    const outPath = path.resolve(opts.output);
    fs.writeFileSync(outPath, JSON.stringify(db, null, 2), 'utf8');
    console.log(`\n  💾 ${outPath}`);

    // ── PHASE 5: Verify ──
    console.log(`\n  🔍 Verifying output JSON...`);
    const verifyDb  = JSON.parse(fs.readFileSync(outPath, 'utf8'));
    const verifyIdx = new Map();
    (verifyDb.rows || []).forEach(row => {
        const a = row?.doc?.data?.arn;
        if (a) verifyIdx.set(a, row.doc);
    });

    let pass = 0, fail = 0;
    const failures = [];
    for (const [arn, files] of updates) {
        const doc = verifyIdx.get(arn);
        if (!doc) { fail++; failures.push(`  ❌ ${arn}: not found in output`); continue; }
        const imgCount = (doc.data?.images || []).length;
        const thumb    = doc.data?.thumbnail?.name || '';
        if (imgCount === files.length && thumb === [...files].sort()[0]) { pass++; }
        else { fail++; failures.push(`  ❌ ${arn}: expected ${files.length} images, got ${imgCount}`); }
    }

    if (fail === 0) {
        console.log(`  ✅ Verification PASSED — all ${pass} ARNs confirmed.`);
    } else {
        console.log(`  ⚠️  Verification: ${pass} passed, ${fail} FAILED`);
        failures.slice(0, 20).forEach(f => console.log(f));
    }

    console.log(`\n  ✅ Match-images complete.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Main
// ══════════════════════════════════════════════════════════════

async function main() {
    const opts = parseArgs(process.argv);

    console.log('\n  ┌──────────────────────────────────────────────┐');
    console.log('  │  Data Extraction CLI                         │');
    console.log('  └──────────────────────────────────────────────┘');

    if (opts.command === 'excel') {
        runExcel(opts);
    } else if (opts.command === 'pdf') {
        await runPdf(opts);
    } else if (opts.command === 'locations') {
        runLocations(opts);
    } else if (opts.command === 'diff') {
        runDiffNew(opts);
        runDiffUpdates(opts);
    } else if (opts.command === 'diff-new') {
        runDiffNew(opts);
    } else if (opts.command === 'diff-updates') {
        runDiffUpdates(opts);
    } else if (opts.command === 'patch') {
        runPatch(opts);
    } else if (opts.command === 'patch-import') {
        runPatchImport(opts);
    } else if (opts.command === 'patch-images') {
        runPatchImages(opts);
    } else if (opts.command === 'match-images') {
        runMatchImages(opts);
    }

    console.log('  Done! 🎉\n');
}

main().catch(err => {
    console.error('\n  ❌ Error:', err.message || err);
    process.exit(1);
});
