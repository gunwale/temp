#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════════
//  Data Extraction CLI
//  Export CouchDB data to Excel workbooks or PDF catalog
//  Requires Node 18+
// ═══════════════════════════════════════════════════════════════

// ── Auto-configure memory limits ──────────────────────────────
// Re-spawn with 6 GB heap + GC access if not already set
const MAX_HEAP_MB = 6144;
if (!process.env.__CLI_MEM_SET) {
    const { execFileSync } = await import('child_process');
    try {
        execFileSync(process.execPath, [
            `--max-old-space-size=${MAX_HEAP_MB}`,
            '--expose-gc',
            ...process.argv.slice(1),
        ], {
            stdio: 'inherit',
            env: { ...process.env, __CLI_MEM_SET: '1' },
        });
    } catch (e) {
        process.exit(e.status || 1);
    }
    process.exit(0);
}

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// ══════════════════════════════════════════════════════════════
//  Help
// ══════════════════════════════════════════════════════════════

function printHelp() {
    console.log(`
  ┌──────────────────────────────────────────────┐
  │  Data Extraction CLI                         │
  │  Export CouchDB data to Excel & PDF          │
  └──────────────────────────────────────────────┘

  Usage:
    node cli.mjs <command> <input> [options]

  Commands:
    excel <file>          Export all entities to separate Excel workbooks
    pdf <file>            Generate artwork catalog PDF (one page per artwork)
    locations <file>      Extract unique buildings & ARN location patch CSV
    diff <file>           Run both diff-new and diff-updates
    diff-new <file>       Find new/removed ARNs (masterlist vs CouchDB)
    diff-updates <file>   Find updated fields for existing ARNs
    help                  Show this help message

  Arguments:
    <file>          Path to couchdb.json or couchdb.txt

  Options (excel):
    -o, --output <prefix>   Output filename prefix (default: "export")

  Options (pdf):
    -o, --output <path>     Output PDF filename (default: "artwork_catalog.pdf")
    --images <dir>          Local image directory mirroring S3 paths
                            Images are resolved as: <dir>/<s3_path>
                            e.g. --images ./assets will look for
                            ./assets/protected/common/artifact/SG/xxx.jpg

  Options (locations):
    -o, --output <prefix>   Output filename prefix (default: "sg")
    --country <name>        Filter by country (default: "Singapore")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")

  Options (diff, diff-new, diff-updates):
    --masterlist <xlsx>     Path to the masterlist Excel file (required)
    -o, --output <prefix>   Output filename prefix (default: "diff")
    --target <type>         Target "artwork", "gift", or "all" (default: "all")

  Examples:
    node cli.mjs help
    node cli.mjs excel ./couchdb.json
    node cli.mjs pdf ./couchdb.json -o report.pdf --images ./s3_mirror
    node cli.mjs locations ./couchdb.json --target artwork
    node cli.mjs locations ./couchdb.json --country Thailand -o th
    node cli.mjs diff ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target artwork
    node cli.mjs diff-updates ./couchdb.json --masterlist "2025 SG ARN Masterlist.xlsx" --target gift
`);
}

// ══════════════════════════════════════════════════════════════
//  Argument Parsing
// ══════════════════════════════════════════════════════════════

function parseArgs(argv) {
    const args = argv.slice(2);

    if (args.length === 0 || args[0] === 'help' || args.includes('-h') || args.includes('--help')) {
        printHelp();
        process.exit(0);
    }

    const command = args[0];
    if (!['excel', 'pdf', 'locations', 'diff', 'diff-new', 'diff-updates'].includes(command)) {
        console.error(`\n  ❌ Unknown command "${command}". Use "excel", "pdf", "locations", "diff", "diff-new", "diff-updates", or "help".\n`);
        process.exit(1);
    }

    const input = args[1];
    if (!input) {
        console.error(`\n  ❌ Missing input file. Usage: node cli.mjs ${command} <couchdb.json>\n`);
        process.exit(1);
    }

    const resolvedInput = path.resolve(input);
    if (!fs.existsSync(resolvedInput)) {
        console.error(`\n  ❌ File not found: ${resolvedInput}\n`);
        process.exit(1);
    }

    const parsed = { command, input: resolvedInput, output: null, images: null, country: 'Singapore', masterlist: null, target: 'all' };

    // Defaults
    if (command === 'excel') parsed.output = 'export';
    if (command === 'pdf') parsed.output = 'artwork_catalog.pdf';
    if (command === 'locations') parsed.output = 'sg';
    if (command === 'diff' || command === 'diff-new' || command === 'diff-updates') parsed.output = 'diff';

    // Parse remaining options
    for (let i = 2; i < args.length; i++) {
        switch (args[i]) {
            case '-o':
            case '--output':
                parsed.output = args[++i];
                break;
            case '--images':
                parsed.images = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.images)) {
                    console.error(`\n  ❌ Images directory not found: ${parsed.images}\n`);
                    process.exit(1);
                }
                break;
            case '--country':
                parsed.country = args[++i];
                break;
            case '--masterlist':
                parsed.masterlist = path.resolve(args[++i]);
                if (!fs.existsSync(parsed.masterlist)) {
                    console.error(`\n  ❌ Masterlist file not found: ${parsed.masterlist}\n`);
                    process.exit(1);
                }
                break;
            case '--target':
                parsed.target = args[++i]?.toLowerCase();
                if (!['artwork', 'gift', 'all'].includes(parsed.target)) {
                    console.error(`\n  ❌ Invalid target "${parsed.target}". Use "artwork", "gift", or "all".\n`);
                    process.exit(1);
                }
                break;
            default:
                console.error(`\n  ❌ Unknown option "${args[i]}". Run "node cli.mjs help" for usage.\n`);
                process.exit(1);
        }
    }

    return parsed;
}

// ══════════════════════════════════════════════════════════════
//  Flatten Helpers
// ══════════════════════════════════════════════════════════════

function camelToTitle(str) {
    if (!str) return '';
    let res = str.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
    res = res.replace(/Id$/i, 'ID');
    res = res.replace(/^Arn$/i, 'ARN');
    return res;
}

function getColumnName(parentPath, key) {
    let cleanKey = camelToTitle(key);
    if (!parentPath) return cleanKey;
    if (parentPath === 'data') return cleanKey;
    if (parentPath.startsWith('data_')) {
        let cleanPath = parentPath.substring(5).split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    if (parentPath.startsWith('metadata')) {
        let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
        return `${cleanPath} ${cleanKey}`;
    }
    let cleanPath = parentPath.split('_').map(camelToTitle).join(' ');
    return `${cleanPath} ${cleanKey}`;
}

function flattenObject(ob, parentPath = '') {
    const toReturn = {};
    for (const i in ob) {
        if (!ob.hasOwnProperty(i)) continue;
        let newPath = parentPath ? parentPath + '_' + i : i;
        if ((typeof ob[i]) === 'object' && ob[i] !== null) {
            if (Array.isArray(ob[i])) {
                let str = JSON.stringify(ob[i]);
                if (str.length > 32000) str = str.substring(0, 32000) + '... [TRUNCATED]';
                toReturn[getColumnName(parentPath, i)] = str;
            } else {
                const flatObject = flattenObject(ob[i], newPath);
                for (const x in flatObject) {
                    if (!flatObject.hasOwnProperty(x)) continue;
                    toReturn[x] = flatObject[x];
                }
            }
        } else {
            let val = ob[i];
            if (typeof val === 'string' && val.length > 32000) {
                val = val.substring(0, 32000) + '... [TRUNCATED]';
            }
            toReturn[getColumnName(parentPath, i)] = val;
        }
    }
    return toReturn;
}

// ══════════════════════════════════════════════════════════════
//  Data Loading
// ══════════════════════════════════════════════════════════════

function loadDocuments(inputFilePath) {
    console.log(`\n  📂 Loading ${inputFilePath}...`);
    const rawData = fs.readFileSync(inputFilePath, 'utf8');
    const data = JSON.parse(rawData);
    return data.rows.filter(r => r.doc).map(r => r.doc);
}

function categorizeDocuments(docs) {
    const collections = {};      // for Excel (flattened)
    const rawCollections = {};   // for PDF (raw docs)

    for (const doc of docs) {
        let docType = null;
        if (doc.metadata && doc.metadata.docType) docType = doc.metadata.docType;
        else if (doc.docType) docType = doc.docType;
        else if (doc.type) docType = doc.type;
        if (!docType || docType.startsWith('_design/')) continue;

        let isGift = doc.data && doc.data.isGift === true;

        // Clone for flattening (we strip internal fields)
        const docCopy = JSON.parse(JSON.stringify(doc));
        delete docCopy._id;
        delete docCopy._rev;
        delete docCopy['~version'];
        delete docCopy._attachments;
        delete docCopy._conflicts;

        const flattenedDoc = flattenObject(docCopy);

        let sheetName = docType.replace('io.uob.resources.', '');
        if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

        let collectionName = sheetName;
        if (sheetName === 'artifact') {
            collectionName = isGift ? 'gift' : 'artwork';
        }

        if (!collections[collectionName]) collections[collectionName] = [];
        collections[collectionName].push(flattenedDoc);

        if (!rawCollections[collectionName]) rawCollections[collectionName] = [];
        rawCollections[collectionName].push(doc);
    }

    return { collections, rawCollections };
}

// ══════════════════════════════════════════════════════════════
//  Excel Export
// ══════════════════════════════════════════════════════════════

function runExcel(opts) {
    const docs = loadDocuments(opts.input);
    const { collections } = categorizeDocuments(docs);

    console.log(`  ✓ Found ${Object.keys(collections).length} collections\n`);

    const xlsx = require('xlsx');
    let count = 0;

    for (const [name, records] of Object.entries(collections)) {
        const fileName = `${opts.output}_${name}.xlsx`;
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(records);
        let safeSheet = name.length > 31 ? name.substring(0, 31) : name;
        xlsx.utils.book_append_sheet(wb, ws, safeSheet);
        xlsx.writeFile(wb, fileName);
        console.log(`  📊 ${fileName}  (${records.length} records)`);
        count++;
    }

    console.log(`\n  ✅ ${count} Excel file(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  PDF Export — Artwork Catalog
// ══════════════════════════════════════════════════════════════

const IMAGE_MAX_PX = 800;    // max dimension (width or height)
const IMAGE_QUALITY = 75;    // JPEG quality (1-100)
const CACHE_DIR = path.join(__dirname, '.image_cache');

/**
 * Resolve the original image path for a document.
 * Tries URL-encoded path first, then decoded fallback.
 */
function resolveOriginalImage(imagesDir, doc) {
    const images = doc.data && doc.data.images;
    if (!images || images.length === 0) return null;
    const imgUrl = images[0].url;

    // Try literal path (URL-encoded folder names)
    const localPath = path.join(imagesDir, imgUrl);
    if (fs.existsSync(localPath)) return localPath;

    // Fallback: URL-decoded path (e.g. %20 → space)
    try {
        const decodedUrl = decodeURIComponent(imgUrl);
        if (decodedUrl !== imgUrl) {
            const decodedPath = path.join(imagesDir, decodedUrl);
            if (fs.existsSync(decodedPath)) return decodedPath;
        }
    } catch { /* ignore decode errors */ }
    return null;
}

/**
 * Pre-process images: resize + compress into .image_cache/
 * Returns a Map<docArn, cachedPath>
 */
async function preprocessImages(docs, imagesDir) {
    const sharp = (await import('sharp')).default;

    if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });

    const imageMap = new Map();
    let processed = 0;
    let skipped = 0;
    const missingList = [];

    for (const doc of docs) {
        const arn = doc.data?.arn || doc.identifier || '';
        const originalPath = resolveOriginalImage(imagesDir, doc);
        if (!originalPath) {
            // Record expected path for debugging
            const imgUrl = doc.data?.images?.[0]?.url;
            const expectedPath = imgUrl ? path.join(imagesDir, imgUrl) : null;
            missingList.push({ arn, expectedPath });
            continue;
        }

        // Cache key: use a safe filename from the original
        const ext = path.extname(originalPath).toLowerCase();
        const baseName = path.basename(originalPath, ext);
        const cachedPath = path.join(CACHE_DIR, `${baseName}_thumb.jpg`);

        // Skip if already cached
        if (fs.existsSync(cachedPath)) {
            imageMap.set(arn, cachedPath);
            skipped++;
            continue;
        }

        try {
            await sharp(originalPath)
                .resize(IMAGE_MAX_PX, IMAGE_MAX_PX, { fit: 'inside', withoutEnlargement: true })
                .jpeg({ quality: IMAGE_QUALITY, mozjpeg: true })
                .toFile(cachedPath);
            imageMap.set(arn, cachedPath);
            processed++;
        } catch (err) {
            console.error(`  ⚠  Failed to process ${path.basename(originalPath)}: ${err.message}`);
        }
    }

    console.log(`  🖼  Images: ${processed} resized, ${skipped} cached, ${missingList.length} not found`);

    // Show first 5 missing paths as examples
    if (missingList.length > 0) {
        const show = missingList.slice(0, 5);
        show.forEach(m => {
            console.log(`     ✗ ${m.arn} → ${m.expectedPath || '(no image URL)'}`);
        });
        if (missingList.length > 5) {
            console.log(`     ... and ${missingList.length - 5} more`);
        }
        // Write full list to log file
        const logPath = path.join(__dirname, 'missing_images.log');
        const logLines = missingList.map(m => `${m.arn}\t${m.expectedPath || 'N/A'}`).join('\n');
        fs.writeFileSync(logPath, logLines + '\n');
        console.log(`  📝 Full list saved to missing_images.log`);
    }

    return imageMap;
}

const CHUNK_SIZE = 100;  // pages per rendering batch (lower = less RAM)

/**
 * Render a collection in chunks and merge into a single PDF.
 * This keeps peak memory proportional to CHUNK_SIZE instead of total pages.
 */
async function renderChunked(docs, imageResolver, outputPath, catalogTitle) {
    const { renderToFile } = await import('@react-pdf/renderer');
    const { createArtworkCatalog } = await import('./pdf/ArtworkCatalog.mjs');
    const { PDFDocument } = await import('pdf-lib');

    const totalPages = docs.length;
    const totalChunks = Math.ceil(totalPages / CHUNK_SIZE);

    // If small enough, render directly (no chunking overhead)
    if (totalPages <= CHUNK_SIZE) {
        console.log(`  ⏳ Rendering ${totalPages} pages to ${outputPath}...`);
        const catalog = createArtworkCatalog(docs, imageResolver, catalogTitle);
        await renderToFile(catalog, outputPath);
        console.log(`  ✓ ${outputPath}`);
        return;
    }

    console.log(`  ⏳ Rendering ${totalPages} pages in ${totalChunks} chunks (${CHUNK_SIZE}/chunk) to ${outputPath}...`);

    const tempDir = path.join(__dirname, '.pdf_temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const tempFiles = [];

    for (let i = 0; i < totalChunks; i++) {
        const start = i * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, totalPages);
        const chunk = docs.slice(start, end);
        const tempFile = path.join(tempDir, `chunk_${i}.pdf`);

        const heapMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(0);
        console.log(`     chunk ${i + 1}/${totalChunks} (pages ${start + 1}–${end}) [heap: ${heapMB} MB]`);
        const catalog = createArtworkCatalog(chunk, imageResolver, catalogTitle);
        await renderToFile(catalog, tempFile);
        tempFiles.push(tempFile);

        // Force GC between chunks to free memory
        if (global.gc) global.gc();
    }

    // Merge all chunks with pdf-lib
    console.log(`  📎 Merging ${totalChunks} chunks...`);
    const mergedPdf = await PDFDocument.create();

    for (const tempFile of tempFiles) {
        const chunkBytes = fs.readFileSync(tempFile);
        const chunkPdf = await PDFDocument.load(chunkBytes);
        const pages = await mergedPdf.copyPages(chunkPdf, chunkPdf.getPageIndices());
        pages.forEach(page => mergedPdf.addPage(page));
    }

    const mergedBytes = await mergedPdf.save();
    fs.writeFileSync(outputPath, mergedBytes);

    // Cleanup temp files
    for (const f of tempFiles) fs.unlinkSync(f);
    fs.rmSync(tempDir, { recursive: true });

    console.log(`  ✓ ${outputPath} (${totalPages} pages)`);
}

async function runPdf(opts) {
    let docs = loadDocuments(opts.input);
    const { rawCollections } = categorizeDocuments(docs);

    // Free raw docs array to reclaim ~130 MB
    docs = null;
    if (global.gc) global.gc();

    const artworks = rawCollections.artwork || [];
    const gifts = rawCollections.gift || [];

    if (artworks.length === 0 && gifts.length === 0) {
        console.error('\n  ❌ No artwork or gift records found in the input file.\n');
        process.exit(1);
    }

    console.log(`  ✓ Found ${artworks.length} artworks, ${gifts.length} gifts\n`);

    // Pre-process images (resize + compress)
    let imageMap = new Map();
    if (opts.images) {
        console.log(`  🖼  Image directory: ${opts.images}`);
        console.log(`  📐 Resizing to max ${IMAGE_MAX_PX}px, ${IMAGE_QUALITY}% JPEG quality`);
        const allDocs = [...artworks, ...gifts];
        imageMap = await preprocessImages(allDocs, opts.images);
    }

    // Image resolver uses pre-processed cache
    const imageResolver = (doc) => {
        const arn = doc.data?.arn || doc.identifier || '';
        return imageMap.get(arn) || null;
    };

    // Determine output base (strip .pdf if present)
    const outputBase = opts.output.replace(/\.pdf$/i, '');

    // Generate artwork PDF (chunked)
    if (artworks.length > 0) {
        const artworkPath = `${outputBase}_artwork.pdf`;
        await renderChunked(artworks, imageResolver, artworkPath, 'Artwork Catalog');
    }

    // Generate gift PDF (chunked)
    if (gifts.length > 0) {
        const giftPath = `${outputBase}_gift.pdf`;
        await renderChunked(gifts, imageResolver, giftPath, 'Gift Catalog');
    }

    console.log(`\n  ✅ PDF catalog(s) generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Locations Extract
// ══════════════════════════════════════════════════════════════

function escCsv(v) {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function isTargetMatch(arn, cdbDoc, target) {
    if (!target || target === 'all') return true;
    const isGift = cdbDoc ? (cdbDoc.data?.isGift === true) : arn.toUpperCase().startsWith('GRN');
    if (target === 'artwork') return !isGift;
    if (target === 'gift') return isGift;
    return true;
}

function runLocations(opts) {
    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');

    // Filter by target (artwork vs gift)
    const targetFiltered = artifacts.filter(d => isTargetMatch(d.data?.arn || '', d, opts.target));

    // Filter by country (match countryISOCode or coCode)
    const countryFilter = opts.country.toLowerCase();
    const filtered = targetFiltered.filter(d => {
        const loc = d.data?.location;
        const co = d.data?.coCode || '';
        if (!loc) return false;
        return (loc.countryISOCode || '').toLowerCase().includes(countryFilter)
            || co.toLowerCase().includes(countryFilter);
    });

    console.log(`  ✓ Found ${artifacts.length} total artifacts`);
    if (opts.target !== 'all') {
        console.log(`  ✓ ${targetFiltered.length} artifacts match target "${opts.target}"`);
    }
    console.log(`  ✓ ${filtered.length} artifacts match country "${opts.country}"\n`);

    if (filtered.length === 0) {
        console.error('  ❌ No artifacts found for that country.\n');
        process.exit(1);
    }

    // ── 1. Unique buildings ──
    const buildingMap = new Map();
    filtered.forEach(d => {
        const loc = d.data.location;
        const building = loc.building || loc.office || '-';
        if (!buildingMap.has(building)) {
            buildingMap.set(building, {
                building, address: loc.address, postalCode: loc.postalCode,
                city: loc.city, country: loc.countryISOCode, count: 0,
            });
        }
        const entry = buildingMap.get(building);
        entry.count++;
        if (entry.address === '-' && loc.address !== '-') entry.address = loc.address;
        if (entry.postalCode === '-' && loc.postalCode !== '-') entry.postalCode = loc.postalCode;
    });

    const buildingsFile = `${opts.output}_unique_buildings.csv`;
    let csv = 'Building,Address,Postal Code,Country,Artifact Count\n';
    for (const [, b] of [...buildingMap].sort((a, b) => a[0].localeCompare(b[0]))) {
        csv += [b.building, b.address, b.postalCode, b.country, b.count].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(buildingsFile, csv);
    console.log(`  📍 ${buildingsFile}  (${buildingMap.size} unique buildings)`);

    // ── 2. ARN-to-location patch CSV ──
    const patchFile = `${opts.output}_arn_location_patch.csv`;
    let patchCsv = 'ARN,Title,Is Gift,Current Building,Current Floor,Current Room,Current Office,Current Location ID,New Building,New Floor,New Room,New Office\n';
    for (const d of filtered.sort((a, b) => (a.data?.arn || '').localeCompare(b.data?.arn || ''))) {
        const loc = d.data.location || {};
        patchCsv += [
            d.data.arn, d.data.title, d.data.isGift ? 'Yes' : 'No',
            loc.building, loc.floor, loc.room, loc.office, loc.identifier,
            '', '', '', '',
        ].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(patchFile, patchCsv);
    console.log(`  📋 ${patchFile}  (${filtered.length} artifacts)`);

    console.log(`\n  ✅ Location files generated.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Diff — Masterlist vs CouchDB
// ══════════════════════════════════════════════════════════════

/**
 * Load masterlist Excel into a Map<ARN, record>.
 * Handles the 3-row header in the Audit Copy sheet.
 */
function loadMasterlist(xlsxPath) {
    const xlsx = require('xlsx');
    const wb = xlsx.readFile(xlsxPath);
    const ws = wb.Sheets[wb.SheetNames[0]]; // First sheet
    const raw = xlsx.utils.sheet_to_json(ws, { header: 1 });

    // Find the header row (contains 'ARN')
    let headerIdx = -1;
    for (let i = 0; i < Math.min(10, raw.length); i++) {
        if (raw[i] && raw[i].includes('ARN')) { headerIdx = i; break; }
    }
    if (headerIdx === -1) {
        console.error('  ❌ Could not find header row with "ARN" column in masterlist.\n');
        process.exit(1);
    }

    const headers = raw[headerIdx];
    const map = new Map();

    for (let i = headerIdx + 1; i < raw.length; i++) {
        const row = raw[i];
        if (!row || !row[1]) continue; // col 1 = ARN
        const record = {};
        headers.forEach((h, j) => {
            if (h && row[j] !== undefined && row[j] !== null) {
                record[h] = String(row[j]).replace(/^'/, '').trim(); // strip leading apostrophe
            }
        });
        if (record.ARN) map.set(record.ARN, record);
    }
    return map;
}

/**
 * Build a comparable record from a CouchDB document.
 */
function cdbToComparable(doc) {
    const d = doc.data || {};
    const loc = d.location || {};
    return {
        ARN: d.arn || '',
        Title: d.title || '',
        Artist: d.artist?.name || '',
        Medium: d.medium || '',
        'Entity Code': d.coCode || '',
        Country: loc.countryISOCode || '',
        Entity: d.entity || '',
        Status: d.status || '',
        'Building Name': loc.building || '',
        'Office Name': loc.office || '',
        Floor: String(loc.floor || ''),
        Room: loc.room || '',
        Address: loc.address || '',
        'Postal Code': String(loc.postalCode || ''),
        Category: d.category || '',
    };
}

function runDiffNew(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');
    const cdbMap = new Map();
    artifacts.forEach(d => { if (d.data?.arn) cdbMap.set(d.data.arn, d); });
    console.log(`  ✓ ${cdbMap.size} ARNs in CouchDB\n`);

    // Filter masterMap and cdbMap keys by target
    const masterKeys = [...masterMap.keys()].filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));
    const cdbKeys = [...cdbMap.keys()].filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));

    if (opts.target !== 'all') {
        console.log(`  ✓ ${masterKeys.length} masterlist ARNs match target "${opts.target}"`);
        console.log(`  ✓ ${cdbKeys.length} CouchDB ARNs match target "${opts.target}"\n`);
    }

    const newARNs = masterKeys.filter(a => !cdbMap.has(a)).sort();
    const removedARNs = cdbKeys.filter(a => !masterMap.has(a)).sort();

    // Write new ARNs CSV
    const newFile = `${opts.output}_new_arns.csv`;
    let newCsv = 'ARN,Title,Artist,Entity Code,Country,Entity,Status,Building Name,Office Name,Floor,Room\n';
    for (const arn of newARNs) {
        const r = masterMap.get(arn);
        newCsv += [r.ARN, r.Title, r.Artist, r['Entity Code'], r.Country, r.Entity, r.Status,
            r['Building Name'], r['Office Name'], r.Floor, r.Room].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(newFile, newCsv);
    console.log(`  🆕 ${newFile}  (${newARNs.length} new ARNs)`);

    // Write removed ARNs CSV
    const removedFile = `${opts.output}_removed_arns.csv`;
    let removedCsv = 'ARN,Title,Artist,Entity Code,Status,Building Name\n';
    for (const arn of removedARNs) {
        const c = cdbToComparable(cdbMap.get(arn));
        removedCsv += [c.ARN, c.Title, c.Artist, c['Entity Code'], c.Status, c['Building Name']].map(escCsv).join(',') + '\n';
    }
    fs.writeFileSync(removedFile, removedCsv);
    console.log(`  🗑️  ${removedFile}  (${removedARNs.length} in CouchDB but not in masterlist)`);

    console.log(`\n  ✅ Diff (new/removed) complete.\n`);
}

function runDiffUpdates(opts) {
    if (!opts.masterlist) {
        console.error('  ❌ Missing --masterlist <xlsx>. See "node cli.mjs help".\n');
        process.exit(1);
    }

    console.log(`  📑 Masterlist: ${path.basename(opts.masterlist)}`);
    const masterMap = loadMasterlist(opts.masterlist);
    console.log(`  ✓ ${masterMap.size} ARNs in masterlist`);

    const docs = loadDocuments(opts.input);
    const artifacts = docs.filter(d => d.metadata?.docType === 'io.uob.resources.artifact');
    const cdbMap = new Map();
    artifacts.forEach(d => { if (d.data?.arn) cdbMap.set(d.data.arn, d); });
    console.log(`  ✓ ${cdbMap.size} ARNs in CouchDB\n`);

    const inBoth = [...masterMap.keys()].filter(a => cdbMap.has(a))
        .filter(a => isTargetMatch(a, cdbMap.get(a), opts.target));

    if (opts.target !== 'all') {
        console.log(`  ✓ ${inBoth.length} overlapping ARNs match target "${opts.target}"\n`);
    }

    // Fields to compare
    const compareFields = [
        'Title', 'Artist', 'Medium', 'Entity Code', 'Country', 'Entity',
        'Status', 'Building Name', 'Office Name', 'Floor', 'Room',
        'Address', 'Postal Code', 'Category',
    ];

    const norm = (v) => String(v || '').replace(/^'+/, '').trim().toLowerCase().replace(/^-$/, '');

    const changes = [];

    for (const arn of inBoth) {
        const master = masterMap.get(arn);
        const cdb = cdbToComparable(cdbMap.get(arn));
        const diffs = [];

        for (const field of compareFields) {
            const mv = norm(master[field]);
            const cv = norm(cdb[field]);
            if (mv !== cv) {
                diffs.push({ field, couchdb: cdb[field] || '', masterlist: master[field] || '' });
            }
        }

        if (diffs.length > 0) {
            changes.push({ arn, diffs });
        }
    }

    // Write updates CSV
    const updatesFile = `${opts.output}_updated_arns.csv`;
    let csv = 'ARN,Field,CouchDB Value,Masterlist Value\n';
    for (const { arn, diffs } of changes.sort((a, b) => a.arn.localeCompare(b.arn))) {
        for (const d of diffs) {
            csv += [arn, d.field, d.couchdb, d.masterlist].map(escCsv).join(',') + '\n';
        }
    }
    fs.writeFileSync(updatesFile, csv);

    const totalFields = changes.reduce((s, c) => s + c.diffs.length, 0);
    console.log(`  📝 ${updatesFile}  (${changes.length} ARNs with ${totalFields} field changes)`);

    // Summary of most changed fields
    const fieldCounts = {};
    changes.forEach(c => c.diffs.forEach(d => { fieldCounts[d.field] = (fieldCounts[d.field] || 0) + 1; }));
    console.log('\n  Field change summary:');
    for (const [f, c] of Object.entries(fieldCounts).sort((a, b) => b[1] - a[1])) {
        console.log(`     ${String(c).padStart(5)}  ${f}`);
    }

    console.log(`\n  ✅ Diff (updates) complete.\n`);
}

// ══════════════════════════════════════════════════════════════
//  Main
// ══════════════════════════════════════════════════════════════

async function main() {
    const opts = parseArgs(process.argv);

    console.log('\n  ┌──────────────────────────────────────────────┐');
    console.log('  │  Data Extraction CLI                         │');
    console.log('  └──────────────────────────────────────────────┘');

    if (opts.command === 'excel') {
        runExcel(opts);
    } else if (opts.command === 'pdf') {
        await runPdf(opts);
    } else if (opts.command === 'locations') {
        runLocations(opts);
    } else if (opts.command === 'diff') {
        runDiffNew(opts);
        runDiffUpdates(opts);
    } else if (opts.command === 'diff-new') {
        runDiffNew(opts);
    } else if (opts.command === 'diff-updates') {
        runDiffUpdates(opts);
    }

    console.log('  Done! 🎉\n');
}

main().catch(err => {
    console.error('\n  ❌ Error:', err.message || err);
    process.exit(1);
});
